﻿namespace Lab2
{
    partial class Lab2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.firstNamelabel = new System.Windows.Forms.Label();
            this.firstNametextBox = new System.Windows.Forms.TextBox();
            this.lastNamelabel = new System.Windows.Forms.Label();
            this.middleNamelabel = new System.Windows.Forms.Label();
            this.middleNametextBox = new System.Windows.Forms.TextBox();
            this.lastNametextBox = new System.Windows.Forms.TextBox();
            this.fullNamelabel = new System.Windows.Forms.Label();
            this.perferredTitletextBox = new System.Windows.Forms.TextBox();
            this.perferredTitlelabel = new System.Windows.Forms.Label();
            this.format1Button = new System.Windows.Forms.Button();
            this.format2Button = new System.Windows.Forms.Button();
            this.format3Button = new System.Windows.Forms.Button();
            this.format4Button = new System.Windows.Forms.Button();
            this.format5Button = new System.Windows.Forms.Button();
            this.format6Button = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // firstNamelabel
            // 
            this.firstNamelabel.AutoSize = true;
            this.firstNamelabel.Location = new System.Drawing.Point(509, 88);
            this.firstNamelabel.Name = "firstNamelabel";
            this.firstNamelabel.Size = new System.Drawing.Size(122, 25);
            this.firstNamelabel.TabIndex = 0;
            this.firstNamelabel.Text = "First Name:";
            // 
            // firstNametextBox
            // 
            this.firstNametextBox.Location = new System.Drawing.Point(710, 88);
            this.firstNametextBox.Name = "firstNametextBox";
            this.firstNametextBox.Size = new System.Drawing.Size(208, 31);
            this.firstNametextBox.TabIndex = 1;
            // 
            // lastNamelabel
            // 
            this.lastNamelabel.AutoSize = true;
            this.lastNamelabel.Location = new System.Drawing.Point(509, 265);
            this.lastNamelabel.Name = "lastNamelabel";
            this.lastNamelabel.Size = new System.Drawing.Size(121, 25);
            this.lastNamelabel.TabIndex = 2;
            this.lastNamelabel.Text = "Last Name:";
            // 
            // middleNamelabel
            // 
            this.middleNamelabel.AutoSize = true;
            this.middleNamelabel.Location = new System.Drawing.Point(506, 179);
            this.middleNamelabel.Name = "middleNamelabel";
            this.middleNamelabel.Size = new System.Drawing.Size(144, 25);
            this.middleNamelabel.TabIndex = 3;
            this.middleNamelabel.Text = "Middle Name:";
            // 
            // middleNametextBox
            // 
            this.middleNametextBox.Location = new System.Drawing.Point(710, 179);
            this.middleNametextBox.Name = "middleNametextBox";
            this.middleNametextBox.Size = new System.Drawing.Size(208, 31);
            this.middleNametextBox.TabIndex = 4;
            // 
            // lastNametextBox
            // 
            this.lastNametextBox.Location = new System.Drawing.Point(710, 265);
            this.lastNametextBox.Name = "lastNametextBox";
            this.lastNametextBox.Size = new System.Drawing.Size(208, 31);
            this.lastNametextBox.TabIndex = 5;
            // 
            // fullNamelabel
            // 
            this.fullNamelabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.fullNamelabel.Location = new System.Drawing.Point(31, 457);
            this.fullNamelabel.Name = "fullNamelabel";
            this.fullNamelabel.Size = new System.Drawing.Size(867, 61);
            this.fullNamelabel.TabIndex = 6;
            // 
            // perferredTitletextBox
            // 
            this.perferredTitletextBox.Location = new System.Drawing.Point(710, 361);
            this.perferredTitletextBox.Name = "perferredTitletextBox";
            this.perferredTitletextBox.Size = new System.Drawing.Size(208, 31);
            this.perferredTitletextBox.TabIndex = 7;
            // 
            // perferredTitlelabel
            // 
            this.perferredTitlelabel.AutoSize = true;
            this.perferredTitlelabel.Location = new System.Drawing.Point(300, 364);
            this.perferredTitlelabel.Name = "perferredTitlelabel";
            this.perferredTitlelabel.Size = new System.Drawing.Size(370, 25);
            this.perferredTitlelabel.TabIndex = 8;
            this.perferredTitlelabel.Text = "Perferred Title (Mr. Dr. Mrs. Ms. Etc. :";
            // 
            // format1Button
            // 
            this.format1Button.Location = new System.Drawing.Point(36, 544);
            this.format1Button.Name = "format1Button";
            this.format1Button.Size = new System.Drawing.Size(175, 53);
            this.format1Button.TabIndex = 9;
            this.format1Button.Text = "Format 1";
            this.format1Button.UseVisualStyleBackColor = true;
            this.format1Button.Click += new System.EventHandler(this.format1Button_Click);
            // 
            // format2Button
            // 
            this.format2Button.Location = new System.Drawing.Point(360, 545);
            this.format2Button.Name = "format2Button";
            this.format2Button.Size = new System.Drawing.Size(224, 52);
            this.format2Button.TabIndex = 10;
            this.format2Button.Text = "Format 2";
            this.format2Button.UseVisualStyleBackColor = true;
            this.format2Button.Click += new System.EventHandler(this.format2Button_Click);
            // 
            // format3Button
            // 
            this.format3Button.Location = new System.Drawing.Point(701, 544);
            this.format3Button.Name = "format3Button";
            this.format3Button.Size = new System.Drawing.Size(185, 53);
            this.format3Button.TabIndex = 11;
            this.format3Button.Text = "Format 3";
            this.format3Button.UseVisualStyleBackColor = true;
            this.format3Button.Click += new System.EventHandler(this.format3Button_Click);
            // 
            // format4Button
            // 
            this.format4Button.Location = new System.Drawing.Point(37, 634);
            this.format4Button.Name = "format4Button";
            this.format4Button.Size = new System.Drawing.Size(174, 53);
            this.format4Button.TabIndex = 12;
            this.format4Button.Text = "Format 4";
            this.format4Button.UseVisualStyleBackColor = true;
            this.format4Button.Click += new System.EventHandler(this.format4Button_Click);
            // 
            // format5Button
            // 
            this.format5Button.Location = new System.Drawing.Point(360, 634);
            this.format5Button.Name = "format5Button";
            this.format5Button.Size = new System.Drawing.Size(224, 53);
            this.format5Button.TabIndex = 13;
            this.format5Button.Text = "Format 5";
            this.format5Button.UseVisualStyleBackColor = true;
            this.format5Button.Click += new System.EventHandler(this.format5Button_Click);
            // 
            // format6Button
            // 
            this.format6Button.Location = new System.Drawing.Point(701, 634);
            this.format6Button.Name = "format6Button";
            this.format6Button.Size = new System.Drawing.Size(184, 53);
            this.format6Button.TabIndex = 14;
            this.format6Button.Text = "Format 6";
            this.format6Button.UseVisualStyleBackColor = true;
            this.format6Button.Click += new System.EventHandler(this.format6Button_Click);
            // 
            // Lab2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(949, 763);
            this.Controls.Add(this.format6Button);
            this.Controls.Add(this.format5Button);
            this.Controls.Add(this.format4Button);
            this.Controls.Add(this.format3Button);
            this.Controls.Add(this.format2Button);
            this.Controls.Add(this.format1Button);
            this.Controls.Add(this.perferredTitlelabel);
            this.Controls.Add(this.perferredTitletextBox);
            this.Controls.Add(this.fullNamelabel);
            this.Controls.Add(this.lastNametextBox);
            this.Controls.Add(this.middleNametextBox);
            this.Controls.Add(this.middleNamelabel);
            this.Controls.Add(this.lastNamelabel);
            this.Controls.Add(this.firstNametextBox);
            this.Controls.Add(this.firstNamelabel);
            this.Name = "Lab2";
            this.Text = "Lab2";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label firstNamelabel;
        private System.Windows.Forms.TextBox firstNametextBox;
        private System.Windows.Forms.Label lastNamelabel;
        private System.Windows.Forms.Label middleNamelabel;
        private System.Windows.Forms.TextBox middleNametextBox;
        private System.Windows.Forms.TextBox lastNametextBox;
        private System.Windows.Forms.Label fullNamelabel;
        private System.Windows.Forms.TextBox perferredTitletextBox;
        private System.Windows.Forms.Label perferredTitlelabel;
        private System.Windows.Forms.Button format1Button;
        private System.Windows.Forms.Button format2Button;
        private System.Windows.Forms.Button format3Button;
        private System.Windows.Forms.Button format4Button;
        private System.Windows.Forms.Button format5Button;
        private System.Windows.Forms.Button format6Button;
    }
}

