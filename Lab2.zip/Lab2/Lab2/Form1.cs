﻿/*
 B8978
 Lab #2
 February 5, 2017
 CIS 199-02
 Lab #2 is designed to help formating names from a list of formats.
 */
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab2
{
    public partial class Lab2 : Form
    {
        public Lab2()
        {
            InitializeComponent();
        }
        // This click event formats to format 1 which is Title, First Name, Middle Name, & Last Name.
        private void format1Button_Click(object sender, EventArgs e) 
        {
            string format1; // Declared format 1 as a string variable
            format1 =perferredTitletextBox.Text + " " + firstNametextBox.Text + " " +middleNametextBox.Text + 
                " " + lastNametextBox.Text; // This is the format for format 1
            fullNamelabel.Text = format1; // This displays the name in format 1 format.
        }
        // This click event formats to format 2 which is First Name, Middle Name, & Last Name.
        private void format2Button_Click(object sender, EventArgs e) 
        {
            string format2; // Declared format 2 as a string variable
            format2 = firstNametextBox.Text + " " + middleNametextBox.Text + " " + lastNametextBox.Text;
            fullNamelabel.Text = format2; // This displays the name in format 2 format.
        }
        // This click event formats to format 3 which is First Name & Last Name
        private void format3Button_Click(object sender, EventArgs e) 
        {
            string format3; // Declared format 3 as a string variable
            format3 = firstNametextBox.Text + " " + lastNametextBox.Text; // This is the format of how format 3 is set up
            fullNamelabel.Text = format3; // This displays the name in format 3 format.
        }
        // This click event formats to format 4 which is Last Name, First Name Middle Name, Perferred Title
        private void format4Button_Click(object sender, EventArgs e)
        {
            string format4; // Declared format 4 as a string variable
            format4 = lastNametextBox.Text + ", " + firstNametextBox.Text + " " +
                middleNametextBox.Text + ", " + perferredTitletextBox.Text; // This is the format of how format 4 is set up
            fullNamelabel.Text = format4; // This displays the name in format 4 format.
                       }
        // This click event formats to format 5 which is Last Name, First Name Middle Name
        private void format5Button_Click(object sender, EventArgs e) 
        {
            string format5; // Declared format 5 as a string variable
            format5 = lastNametextBox.Text + ", " + firstNametextBox.Text + " " +
                middleNametextBox.Text; // This is the format of how format 5 is set up.
            fullNamelabel.Text = format5; // This displays the name in format 5 format.
                }

        private void format6Button_Click(object sender, EventArgs e) // This click event formats to format 6 which is Last Name, First Name
        {
            string format6; // Declared format 6 as a string variable 
            format6 = lastNametextBox.Text + ", " + firstNametextBox.Text; // This is the format of how format 6 is set up.
            fullNamelabel.Text = format6; // This displays the name in format 6 format.
        }
    }
}
