﻿// B8978
// Lab 9
// April 18, 2017
// CIS 199-02
// This Program is design to display the updated dates based on imputs into the classes.
// PreConditions: Months are used one through tweleve. The days are numbers one through thirty one. The years start at 2000
// PostConditions: The format will come back MM/DD/YYYY
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab_9
{
    public class Date // This creates the class
    {

        public int _month; // This creates and declares variable for month
        public int _day; // This creates and declares variable for day
        public int _year; // This creates and declares variable for day
        public Date(int m = 1, int d = 1, int y = 2000) // This is starting label
        {
            day = d; // The letter d will repersent days in the code
            month = m; // The letter m will repersent months in the code
            year = y; // The letter y will repersent years in the code.
        }
        public int month // This helps set up the month
        {
            get
            {
                return _month; // This returns the value of months.
            }
            set
            {
                if (value >= 1 && value <= 12) // This help makes sure no crazy imputs in program
                    _month = value; // This returns the value the person has imputed
                else _month = 1; // If the month isn't a valid then it returns the date back janurary.
            }
        }
        public int day // This sets day for the label.
        {
            get // This pulls it return a day value.
            {
                return _day; // This returns data value.
            }
            set
            {
                if (value >= 1 && value <= 31) // This sets up days in a month.
                    _day = value; // The value is the amount entered.
                else _day = 1; // The number has to be valid or it returns to the first.
            }
        }
        public int year // This sets the year for the label.
        {
            get { return _year; } // This returns a year for the label.
            set
            {
                if (value >= 0) // This allows for no negative years.
                    _year = value; // This makes sure the number is value
                else  _year = 2000; // This year has to be valid or returns  it back 2000
            }
        }
        public override string ToString() // This converts the texts.
        {
            string result; // This gives you final result
            result = month.ToString("D2") + "/" + day.ToString("D2") + "/" + year.ToString("D4"); // This gives you the opening and starting value as 01/01/2000
            return result; // This returns in label and displays 01/01/2000
        }
    }
}
