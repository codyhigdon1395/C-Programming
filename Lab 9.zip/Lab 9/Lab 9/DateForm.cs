﻿// B8978
// Lab 9
// April 18, 2017
// CIS 199-02
// This Program is design to display the updated dates based on imputs into the classes.

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab_9
{
    public partial class DateForm : Form
    {
        // PreConditions: Months are used one through tweleve. The days are numbers one through thirty one. The years start at 2000
        // PostConditions: The format will come back MM/DD/YYYY
            public Date endingDate = new Date(); 
            public DateForm()
        {
            InitializeComponent();
        }
        private void DateForm_Load(object sender, EventArgs e) // This loads the form.
        {
            beginingDatelabel.Text = endingDate.ToString(); // This helps displays begining date of 1/1/2000
        }
// PreConditions: Number has to be between 1 & 12
// PostConditions: The month will be update from January
        private void monthUpdatebutton_Click(object sender, EventArgs e) // This updates month with the click.
        {
            int numberOfmonth; // The number of month is integer type.
            if (int.TryParse(monthTextbox.Text, out numberOfmonth))// This converts text to a number by try parsing.
            {
                endingDate.month = numberOfmonth; // This helps set up the ending the statement.
                beginingDatelabel.Text = endingDate.ToString(); // This is final output
            }
        }      
          // PreConditions: Number has to be between 1 & 31
          // PostConditions: The day will be update from 1st
        private void dayUpdatebutton_Click(object sender, EventArgs e) // This updates the day with a click.
        {
            int dayOfmonth; // The day number of the month.
            if (int.TryParse(dayTextbox.Text, out dayOfmonth)) // This converts the text to a number for the strand.
            {
                endingDate.day = dayOfmonth; // This helps display the ending the label..
                beginingDatelabel.Text = endingDate.ToString();// This is final output
            }
        }
        // PreConditions: Number has to be full year after 2000
        // PostConditions: The year will be update from 2000.
        private void updateYearbutton_Click(object sender, EventArgs e) // This update the year with a click.
        {
            int endingYear; // This creates a variable that helps with ending solution
            if (int.TryParse(yearTextbox.Text, out endingYear)) // This converts the tet to the number.
            {
                endingDate.year = endingYear; // This make the ending year same for the label.
                beginingDatelabel.Text = endingDate.ToString(); // This is final output
            }
        }
    }
}
