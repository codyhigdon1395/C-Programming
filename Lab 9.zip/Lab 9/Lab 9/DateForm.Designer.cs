﻿namespace Lab_9
{
    partial class DateForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.startingDatelabel = new System.Windows.Forms.Label();
            this.beginingDatelabel = new System.Windows.Forms.Label();
            this.monthLabel = new System.Windows.Forms.Label();
            this.monthTextbox = new System.Windows.Forms.TextBox();
            this.monthUpdatebutton = new System.Windows.Forms.Button();
            this.dayLabel = new System.Windows.Forms.Label();
            this.dayTextbox = new System.Windows.Forms.TextBox();
            this.dayUpdatebutton = new System.Windows.Forms.Button();
            this.yearLabel = new System.Windows.Forms.Label();
            this.yearTextbox = new System.Windows.Forms.TextBox();
            this.updateYearbutton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // startingDatelabel
            // 
            this.startingDatelabel.AutoSize = true;
            this.startingDatelabel.Location = new System.Drawing.Point(50, 95);
            this.startingDatelabel.Name = "startingDatelabel";
            this.startingDatelabel.Size = new System.Drawing.Size(63, 25);
            this.startingDatelabel.TabIndex = 0;
            this.startingDatelabel.Text = "Date:";
            // 
            // beginingDatelabel
            // 
            this.beginingDatelabel.AutoSize = true;
            this.beginingDatelabel.Location = new System.Drawing.Point(158, 95);
            this.beginingDatelabel.Name = "beginingDatelabel";
            this.beginingDatelabel.Size = new System.Drawing.Size(0, 25);
            this.beginingDatelabel.TabIndex = 1;
            // 
            // monthLabel
            // 
            this.monthLabel.AutoSize = true;
            this.monthLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.monthLabel.Location = new System.Drawing.Point(41, 171);
            this.monthLabel.Name = "monthLabel";
            this.monthLabel.Size = new System.Drawing.Size(80, 27);
            this.monthLabel.TabIndex = 2;
            this.monthLabel.Text = "Month:";
            // 
            // monthTextbox
            // 
            this.monthTextbox.Location = new System.Drawing.Point(148, 171);
            this.monthTextbox.Name = "monthTextbox";
            this.monthTextbox.Size = new System.Drawing.Size(259, 31);
            this.monthTextbox.TabIndex = 3;
            // 
            // monthUpdatebutton
            // 
            this.monthUpdatebutton.Location = new System.Drawing.Point(454, 160);
            this.monthUpdatebutton.Name = "monthUpdatebutton";
            this.monthUpdatebutton.Size = new System.Drawing.Size(202, 52);
            this.monthUpdatebutton.TabIndex = 4;
            this.monthUpdatebutton.Text = "Update Month";
            this.monthUpdatebutton.UseVisualStyleBackColor = true;
            this.monthUpdatebutton.Click += new System.EventHandler(this.monthUpdatebutton_Click);
            // 
            // dayLabel
            // 
            this.dayLabel.AutoSize = true;
            this.dayLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.dayLabel.Location = new System.Drawing.Point(63, 243);
            this.dayLabel.Name = "dayLabel";
            this.dayLabel.Size = new System.Drawing.Size(58, 27);
            this.dayLabel.TabIndex = 5;
            this.dayLabel.Text = "Day:";
            // 
            // dayTextbox
            // 
            this.dayTextbox.Location = new System.Drawing.Point(148, 239);
            this.dayTextbox.Name = "dayTextbox";
            this.dayTextbox.Size = new System.Drawing.Size(259, 31);
            this.dayTextbox.TabIndex = 6;
            // 
            // dayUpdatebutton
            // 
            this.dayUpdatebutton.Location = new System.Drawing.Point(454, 239);
            this.dayUpdatebutton.Name = "dayUpdatebutton";
            this.dayUpdatebutton.Size = new System.Drawing.Size(202, 53);
            this.dayUpdatebutton.TabIndex = 7;
            this.dayUpdatebutton.Text = "Update Day";
            this.dayUpdatebutton.UseVisualStyleBackColor = true;
            this.dayUpdatebutton.Click += new System.EventHandler(this.dayUpdatebutton_Click);
            // 
            // yearLabel
            // 
            this.yearLabel.AutoSize = true;
            this.yearLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.yearLabel.Location = new System.Drawing.Point(55, 314);
            this.yearLabel.Name = "yearLabel";
            this.yearLabel.Size = new System.Drawing.Size(66, 27);
            this.yearLabel.TabIndex = 8;
            this.yearLabel.Text = "Year:";
            // 
            // yearTextbox
            // 
            this.yearTextbox.Location = new System.Drawing.Point(148, 314);
            this.yearTextbox.Name = "yearTextbox";
            this.yearTextbox.Size = new System.Drawing.Size(259, 31);
            this.yearTextbox.TabIndex = 9;
            // 
            // updateYearbutton
            // 
            this.updateYearbutton.Location = new System.Drawing.Point(454, 314);
            this.updateYearbutton.Name = "updateYearbutton";
            this.updateYearbutton.Size = new System.Drawing.Size(202, 52);
            this.updateYearbutton.TabIndex = 10;
            this.updateYearbutton.Text = "Update Year";
            this.updateYearbutton.UseVisualStyleBackColor = true;
            this.updateYearbutton.Click += new System.EventHandler(this.updateYearbutton_Click);
            // 
            // DateForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(685, 427);
            this.Controls.Add(this.updateYearbutton);
            this.Controls.Add(this.yearTextbox);
            this.Controls.Add(this.yearLabel);
            this.Controls.Add(this.dayUpdatebutton);
            this.Controls.Add(this.dayTextbox);
            this.Controls.Add(this.dayLabel);
            this.Controls.Add(this.monthUpdatebutton);
            this.Controls.Add(this.monthTextbox);
            this.Controls.Add(this.monthLabel);
            this.Controls.Add(this.beginingDatelabel);
            this.Controls.Add(this.startingDatelabel);
            this.Name = "DateForm";
            this.Text = "Lab9";
            this.Load += new System.EventHandler(this.DateForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label startingDatelabel;
        private System.Windows.Forms.Label beginingDatelabel;
        private System.Windows.Forms.Label monthLabel;
        private System.Windows.Forms.TextBox monthTextbox;
        private System.Windows.Forms.Button monthUpdatebutton;
        private System.Windows.Forms.Label dayLabel;
        private System.Windows.Forms.TextBox dayTextbox;
        private System.Windows.Forms.Button dayUpdatebutton;
        private System.Windows.Forms.Label yearLabel;
        private System.Windows.Forms.TextBox yearTextbox;
        private System.Windows.Forms.Button updateYearbutton;
    }
}

