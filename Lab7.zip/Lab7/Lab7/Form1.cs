﻿/* B8978
 * Lab 7
 * March 26, 2017
 * CIS 199-02
 * This Lab is designed to be a interest calculator for present value
 */
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab7
{
    public partial class Lab7 : Form
    {
        public Lab7()
        {
            InitializeComponent();
        }
// Preconditions: The numbers can't be negative when entered in the textboxes
// PostConditions: The number wont be correct if it is a negative number
        public double CalcPresentValue(double fvalue, double airate, int years)
        {
            double presentValue; // The declared value for Present Value
            presentValue = fvalue / Math.Pow(1 + airate, years); // This is the interest calculator equation
            return presentValue; // This returns the present value
        }
    // PreConditions: The values have to be numbers they cant be letters
    // PostConditions: The CalcPresentValue will return the present value needed.
        private void calculateButton_Click(object sender, EventArgs e) // This click even intailizies the program
        {
            double futureValue; // The declared value for Future Value
            double annualInterestrate; // This declared value for Annual Interest Rate
            double presentValue; // The declared value for Present Value
            int numberOfyears; // This declared value for number of years

            if (double.TryParse(futureValuetextBox.Text, out futureValue)) // This parses the future value
            {
                if (double.TryParse(annualInterestrateTextbox.Text, out annualInterestrate)) // This parses the annual interest rate
                {
                    if (int.TryParse(numberOfyearsTextbox.Text, out numberOfyears)) // This parses the number of years
                    {
                        presentValue = CalcPresentValue(futureValue, annualInterestrate, numberOfyears); // This returns the value
                        presentValueamountLabel.Text = presentValue.ToString("C"); // This converts text to currency format
                    }
                    else MessageBox.Show("Invalid Number Of Years!!!"); // This displays if number of years couldnt be parsed.
                }
                else MessageBox.Show("Invalid Interest Rate!!!"); // This displays if Interest Rate can't be parsed/
            }
            else MessageBox.Show("Invalid Future Value!!!"); // This displays if future value can't be parsed.
        }
    }
}

