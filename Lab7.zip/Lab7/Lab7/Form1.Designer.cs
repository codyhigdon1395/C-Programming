﻿namespace Lab7
{
    partial class Lab7
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.futureValuetitleLabel = new System.Windows.Forms.Label();
            this.futureValuetextBox = new System.Windows.Forms.TextBox();
            this.annualInterestRatetitleLabel = new System.Windows.Forms.Label();
            this.annualInterestrateTextbox = new System.Windows.Forms.TextBox();
            this.numberOfyearsTitlelabel = new System.Windows.Forms.Label();
            this.numberOfyearsTextbox = new System.Windows.Forms.TextBox();
            this.presentValuetitleTextbox = new System.Windows.Forms.Label();
            this.presentValueamountLabel = new System.Windows.Forms.Label();
            this.calculateButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // futureValuetitleLabel
            // 
            this.futureValuetitleLabel.AutoSize = true;
            this.futureValuetitleLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.futureValuetitleLabel.Location = new System.Drawing.Point(27, 95);
            this.futureValuetitleLabel.Name = "futureValuetitleLabel";
            this.futureValuetitleLabel.Size = new System.Drawing.Size(143, 27);
            this.futureValuetitleLabel.TabIndex = 0;
            this.futureValuetitleLabel.Text = "Future Value:";
            // 
            // futureValuetextBox
            // 
            this.futureValuetextBox.Location = new System.Drawing.Point(376, 95);
            this.futureValuetextBox.Name = "futureValuetextBox";
            this.futureValuetextBox.Size = new System.Drawing.Size(248, 31);
            this.futureValuetextBox.TabIndex = 1;
            // 
            // annualInterestRatetitleLabel
            // 
            this.annualInterestRatetitleLabel.AutoSize = true;
            this.annualInterestRatetitleLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.annualInterestRatetitleLabel.Location = new System.Drawing.Point(27, 183);
            this.annualInterestRatetitleLabel.Name = "annualInterestRatetitleLabel";
            this.annualInterestRatetitleLabel.Size = new System.Drawing.Size(215, 27);
            this.annualInterestRatetitleLabel.TabIndex = 2;
            this.annualInterestRatetitleLabel.Text = "Annual Interest Rate:";
            // 
            // annualInterestrateTextbox
            // 
            this.annualInterestrateTextbox.Location = new System.Drawing.Point(376, 179);
            this.annualInterestrateTextbox.Name = "annualInterestrateTextbox";
            this.annualInterestrateTextbox.Size = new System.Drawing.Size(248, 31);
            this.annualInterestrateTextbox.TabIndex = 3;
            // 
            // numberOfyearsTitlelabel
            // 
            this.numberOfyearsTitlelabel.AutoSize = true;
            this.numberOfyearsTitlelabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.numberOfyearsTitlelabel.Location = new System.Drawing.Point(27, 271);
            this.numberOfyearsTitlelabel.Name = "numberOfyearsTitlelabel";
            this.numberOfyearsTitlelabel.Size = new System.Drawing.Size(186, 27);
            this.numberOfyearsTitlelabel.TabIndex = 4;
            this.numberOfyearsTitlelabel.Text = "Number Of Years:";
            // 
            // numberOfyearsTextbox
            // 
            this.numberOfyearsTextbox.Location = new System.Drawing.Point(376, 270);
            this.numberOfyearsTextbox.Name = "numberOfyearsTextbox";
            this.numberOfyearsTextbox.Size = new System.Drawing.Size(247, 31);
            this.numberOfyearsTextbox.TabIndex = 5;
            // 
            // presentValuetitleTextbox
            // 
            this.presentValuetitleTextbox.AutoSize = true;
            this.presentValuetitleTextbox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.presentValuetitleTextbox.Location = new System.Drawing.Point(27, 366);
            this.presentValuetitleTextbox.Name = "presentValuetitleTextbox";
            this.presentValuetitleTextbox.Size = new System.Drawing.Size(155, 27);
            this.presentValuetitleTextbox.TabIndex = 6;
            this.presentValuetitleTextbox.Text = "Present Value:";
            // 
            // presentValueamountLabel
            // 
            this.presentValueamountLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.presentValueamountLabel.Location = new System.Drawing.Point(376, 359);
            this.presentValueamountLabel.Name = "presentValueamountLabel";
            this.presentValueamountLabel.Size = new System.Drawing.Size(247, 33);
            this.presentValueamountLabel.TabIndex = 7;
            // 
            // calculateButton
            // 
            this.calculateButton.Location = new System.Drawing.Point(125, 472);
            this.calculateButton.Name = "calculateButton";
            this.calculateButton.Size = new System.Drawing.Size(464, 66);
            this.calculateButton.TabIndex = 8;
            this.calculateButton.Text = "Calculate:";
            this.calculateButton.UseVisualStyleBackColor = true;
            this.calculateButton.Click += new System.EventHandler(this.calculateButton_Click);
            // 
            // Lab7
            // 
            this.AcceptButton = this.calculateButton;
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(794, 804);
            this.Controls.Add(this.calculateButton);
            this.Controls.Add(this.presentValueamountLabel);
            this.Controls.Add(this.presentValuetitleTextbox);
            this.Controls.Add(this.numberOfyearsTextbox);
            this.Controls.Add(this.numberOfyearsTitlelabel);
            this.Controls.Add(this.annualInterestrateTextbox);
            this.Controls.Add(this.annualInterestRatetitleLabel);
            this.Controls.Add(this.futureValuetextBox);
            this.Controls.Add(this.futureValuetitleLabel);
            this.Name = "Lab7";
            this.Text = "Lab 7";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label futureValuetitleLabel;
        private System.Windows.Forms.TextBox futureValuetextBox;
        private System.Windows.Forms.Label annualInterestRatetitleLabel;
        private System.Windows.Forms.TextBox annualInterestrateTextbox;
        private System.Windows.Forms.Label numberOfyearsTitlelabel;
        private System.Windows.Forms.TextBox numberOfyearsTextbox;
        private System.Windows.Forms.Label presentValuetitleTextbox;
        private System.Windows.Forms.Label presentValueamountLabel;
        private System.Windows.Forms.Button calculateButton;
    }
}

