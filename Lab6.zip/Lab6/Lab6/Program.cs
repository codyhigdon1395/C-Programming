﻿/* B8978
 * Lab 6
 * March 12, 2017
 * CIS 199-02
 * This Lab is designed to show different star patterns
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab6
{
    class Program
    {
        static void Main(string[] args)
        {
            int MAINROW; // the current row
            int STARS; // the number of stars
            int SPACES; // the number of spaces

            Console.Write("Pattern A\n"); // This shows title for the pattern
            for (MAINROW = 1; MAINROW <= 11; MAINROW++) // This equation sets up how the row looks.
            {
                for (SPACES = 1; SPACES > MAINROW; SPACES--) // This equation sets up the spaces in the pattern.
                    Console.Write(" "); // This shows spaces in each line.
                for (STARS = 1; STARS <= MAINROW - 1; STARS++) // This equation sets up the number of stars in each row.
                    Console.Write("*"); // This creates the stars.
                Console.WriteLine(); // This writes the saces
            }
            Console.Write("Pattern B\n"); //This displays pattern B above the triangle 
            for (MAINROW = 0; MAINROW <= 11; MAINROW++) // This equation sets up the pattern B
            {
                Console.WriteLine(); // This writes lines 
                for (SPACES = 10; SPACES > MAINROW; SPACES--) // This creates the stars 
                    Console.Write("*"); // This writes the stars
                for (STARS = 1; STARS <= MAINROW - 1; STARS++) // This equations set up the spaces
                    Console.Write(""); // This writes the spaces
            }
            Console.WriteLine("Pattern C\n"); // This displays pattern C above the triangle
            for (MAINROW = 0; MAINROW <= 11; MAINROW++) // This equation sets up the pattern C
            {
                Console.WriteLine(); // This writes the lines
                for (STARS = 0; STARS <= MAINROW - 1; STARS++) // This creates the spaces in the specific pattern.
                    Console.Write(" "); //This creates the spaces.
                for (SPACES = 10; SPACES > MAINROW; SPACES--) // This creates the stars in each row
                    Console.Write("*"); // This creates the stars.
            }
            Console.WriteLine("\n Pattern D\n");//Triangle D name is shown
            for (MAINROW = 1; MAINROW <= 10; MAINROW++) // This equation sets up pattern D.
            {
                Console.WriteLine(); // This writes the lines
                for (SPACES = 10; SPACES > MAINROW; SPACES--) // This creates the spaces in the specific pattern.
                    Console.Write(" "); // This shows the patterns.
                for (STARS = 0; STARS <= MAINROW - 1; STARS++) // This equations sets up the stars in the pattern
                    Console.Write("*"); // This writes the stars for each line.    
            }
           Console.ReadLine(); // This reads the line
        } 
    } 
}

