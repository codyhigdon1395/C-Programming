﻿namespace Lab3
{
    partial class Lab3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.enterMealcostLabel = new System.Windows.Forms.Label();
            this.mealPricetextBox = new System.Windows.Forms.TextBox();
            this.smallTiplabel = new System.Windows.Forms.Label();
            this.smallTipamountLabel = new System.Windows.Forms.Label();
            this.mediumTiplabel = new System.Windows.Forms.Label();
            this.mediumTipamountLabel = new System.Windows.Forms.Label();
            this.largeTiplabel = new System.Windows.Forms.Label();
            this.largeTipamountLabel = new System.Windows.Forms.Label();
            this.calculateTipamountButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // enterMealcostLabel
            // 
            this.enterMealcostLabel.AutoSize = true;
            this.enterMealcostLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.enterMealcostLabel.Location = new System.Drawing.Point(75, 86);
            this.enterMealcostLabel.Name = "enterMealcostLabel";
            this.enterMealcostLabel.Size = new System.Drawing.Size(174, 27);
            this.enterMealcostLabel.TabIndex = 0;
            this.enterMealcostLabel.Text = "Enter Meal Cost:";
            // 
            // mealPricetextBox
            // 
            this.mealPricetextBox.Location = new System.Drawing.Point(336, 86);
            this.mealPricetextBox.Name = "mealPricetextBox";
            this.mealPricetextBox.Size = new System.Drawing.Size(245, 31);
            this.mealPricetextBox.TabIndex = 1;
            // 
            // smallTiplabel
            // 
            this.smallTiplabel.AutoSize = true;
            this.smallTiplabel.Location = new System.Drawing.Point(152, 189);
            this.smallTiplabel.Name = "smallTiplabel";
            this.smallTiplabel.Size = new System.Drawing.Size(97, 25);
            this.smallTiplabel.TabIndex = 2;
            this.smallTiplabel.Text = "15% Tip:";
            // 
            // smallTipamountLabel
            // 
            this.smallTipamountLabel.AutoSize = true;
            this.smallTipamountLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.smallTipamountLabel.Location = new System.Drawing.Point(336, 187);
            this.smallTipamountLabel.Name = "smallTipamountLabel";
            this.smallTipamountLabel.Size = new System.Drawing.Size(2, 27);
            this.smallTipamountLabel.TabIndex = 3;
            // 
            // mediumTiplabel
            // 
            this.mediumTiplabel.AutoSize = true;
            this.mediumTiplabel.Location = new System.Drawing.Point(152, 308);
            this.mediumTiplabel.Name = "mediumTiplabel";
            this.mediumTiplabel.Size = new System.Drawing.Size(97, 25);
            this.mediumTiplabel.TabIndex = 4;
            this.mediumTiplabel.Text = "18% Tip:";
            // 
            // mediumTipamountLabel
            // 
            this.mediumTipamountLabel.AutoSize = true;
            this.mediumTipamountLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.mediumTipamountLabel.Location = new System.Drawing.Point(336, 308);
            this.mediumTipamountLabel.Name = "mediumTipamountLabel";
            this.mediumTipamountLabel.Size = new System.Drawing.Size(2, 27);
            this.mediumTipamountLabel.TabIndex = 5;
            // 
            // largeTiplabel
            // 
            this.largeTiplabel.AutoSize = true;
            this.largeTiplabel.Location = new System.Drawing.Point(152, 418);
            this.largeTiplabel.Name = "largeTiplabel";
            this.largeTiplabel.Size = new System.Drawing.Size(97, 25);
            this.largeTiplabel.TabIndex = 6;
            this.largeTiplabel.Text = "20% Tip:";
            // 
            // largeTipamountLabel
            // 
            this.largeTipamountLabel.AutoSize = true;
            this.largeTipamountLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.largeTipamountLabel.Location = new System.Drawing.Point(340, 411);
            this.largeTipamountLabel.Name = "largeTipamountLabel";
            this.largeTipamountLabel.Size = new System.Drawing.Size(2, 27);
            this.largeTipamountLabel.TabIndex = 7;
            // 
            // calculateTipamountButton
            // 
            this.calculateTipamountButton.Location = new System.Drawing.Point(188, 554);
            this.calculateTipamountButton.Name = "calculateTipamountButton";
            this.calculateTipamountButton.Size = new System.Drawing.Size(441, 70);
            this.calculateTipamountButton.TabIndex = 8;
            this.calculateTipamountButton.Text = "Calculate Tip";
            this.calculateTipamountButton.UseVisualStyleBackColor = true;
            this.calculateTipamountButton.Click += new System.EventHandler(this.calculateTipamountButton_Click);
            // 
            // Lab3
            // 
            this.AcceptButton = this.calculateTipamountButton;
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(693, 670);
            this.Controls.Add(this.calculateTipamountButton);
            this.Controls.Add(this.largeTipamountLabel);
            this.Controls.Add(this.largeTiplabel);
            this.Controls.Add(this.mediumTipamountLabel);
            this.Controls.Add(this.mediumTiplabel);
            this.Controls.Add(this.smallTipamountLabel);
            this.Controls.Add(this.smallTiplabel);
            this.Controls.Add(this.mealPricetextBox);
            this.Controls.Add(this.enterMealcostLabel);
            this.Name = "Lab3";
            this.Text = "Lab3";
            this.Load += new System.EventHandler(this.Lab3_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label enterMealcostLabel;
        private System.Windows.Forms.TextBox mealPricetextBox;
        private System.Windows.Forms.Label smallTiplabel;
        private System.Windows.Forms.Label smallTipamountLabel;
        private System.Windows.Forms.Label mediumTiplabel;
        private System.Windows.Forms.Label mediumTipamountLabel;
        private System.Windows.Forms.Label largeTiplabel;
        private System.Windows.Forms.Label largeTipamountLabel;
        private System.Windows.Forms.Button calculateTipamountButton;
    }
}

