﻿/*
B8978
Lab 3
CIS 199-02
February 12, 2017
This Lab is designed to do tip calculation for a meal.
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab3
{
    public partial class Lab3 : Form
    {
        const decimal SMALLPERCENT = .15M; // This holds the small percent variable
        const decimal MEDIUMPERCENT = .18M; //This holds the medium percent variable
        const decimal LARGEPERCENT = .20M; // This holds the large percent variable
        public Lab3()
        {
            InitializeComponent();
        }

        private void Lab3_Load(object sender, EventArgs e) // This is the load event for the lab
        {
            smallTiplabel.Text = SMALLPERCENT.ToString("p0"); // This converts the small tip to text
            mediumTiplabel.Text = MEDIUMPERCENT.ToString("p0"); // This converts the medium tip to text
            largeTiplabel.Text = LARGEPERCENT.ToString("p0"); // This converts the large tip to text.
        }

        private void calculateTipamountButton_Click(object sender, EventArgs e) // This a click event for tip amount button
        {
           
            decimal mealPrice; // I am declaring meal price as a decimal
            decimal smallTipAmount; // I am declaring small tip amount as a decimal
            decimal mediumTipAmount; // I am declaring medium tip amount as a decimal
            decimal largeTipAmount; // I am declaring large tip amount as a decimal

            mealPrice = decimal.Parse(mealPricetextBox.Text); // This converts meal price for equations

            smallTipAmount = mealPrice * SMALLPERCENT; // This calculates small tip amount
            mediumTipAmount = mealPrice * MEDIUMPERCENT; // This calculates medium tip amount
            largeTipAmount = mealPrice * LARGEPERCENT; // This calculates large tip amount

            smallTipamountLabel.Text = smallTipAmount.ToString("C"); // This converts small tip amount to an amount in currency format
            mediumTipamountLabel.Text = mediumTipAmount.ToString("C"); // This converts medium tip amount to an amount in currency format
            largeTipamountLabel.Text = largeTipAmount.ToString("C"); // This converts large tip amount to an amount in currency format
        }
    }
}
