﻿/*B8978
 *Program 2
 *March 9, 2017
 *CIS 199-02
 * Program is designed to calculate when somone can register for classes.
 */
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Program2
{
    public partial class Program2 : Form
    {
        public Program2()
        {
            InitializeComponent();
        }

        private void findOutbutton_Click(object sender, EventArgs e) // This click event to determines the time you register
        {
            string LastName; // This is string label
            char LastNameLetter; // This char is used for one letter
            LastName = lastNametextBox.Text; // This converts Last Name from textbox to label
            LastNameLetter = LastName[0]; // This chars out the first Letter of Last Name

            string Day1 = "Wednesday, March 29, 2017"; // This string for the First Day of Registration.
            string Day2 = "Thursday, March 30, 2017"; // This string for the Second Day of Registration.
            string Day3 = "Friday, March 31, 2017"; // This string for the Third Day of Registration.
            string Day4 = "Monday, April 3, 2017";  // This string for the Forth Day of Registration.
            string Day5 = "Tuesday, April 4, 2017";  // This string for the Fifth Day of Registration.
            string Day6 = "Wednesday, April 5, 2017"; //  // This string for the Six Day of Registration.

            string Time1 = "8:30 AM"; // This string for the First Time of Registration.
            string Time2 = "10:00 AM"; // This string for the Second Time of Registration.
            string Time3 = "11:30 AM"; // This string for the Third Time of Registration.
            string Time4 = "2:00 PM";  // This string for the Forth Time of Registration.
            string Time5 = "4:00 PM";  // This string for the Fifth Time of Registration.

            if (seniorRadiobutton.Checked || juniorRadiobutton.Checked) // This if statement determines senior or junior radio button is chosen
            {
                if (seniorRadiobutton.Checked) // This detemines if the senior radio button is checked
                {
                    scheduledDatelabel.Text = Day1; // This puts seniors on Day 1 of Registration
                }
                else // This else statement shows if Junior radio button is checked
                {
                    scheduledDatelabel.Text = Day2; // This puts juniors on Day 2 of registration
                }

                if (LastNameLetter <= 'D') // Last Name A-D
                {
                    scheduledTimelabel.Text = Time3; // This displays 11:30 AM in Time Label.
                }
                else if (LastNameLetter <= 'I') // Last Name E-I 
                {
                    scheduledTimelabel.Text = Time4; //This displays 2:00 PM in Time Label
                }
                else if (LastNameLetter <= 'O') // Last Name J-O
                {
                    scheduledTimelabel.Text = Time5; // This displays 4:00 PM in Time Label
                }
                else if (LastNameLetter <= 'S') // Last Name P-S
                {
                    scheduledTimelabel.Text = Time1; // This displays 8:30 AM in Time Label
                }
                else // Last Name T-Z
                {
                    scheduledTimelabel.Text = Time2; // This displays 10:00 AM in Time Label
                }
            }
            else // This else statement is for sophomore or freshman radio button is checked.
            {
                if (sophomoreRadiobutton.Checked) // This if statement determines if sophomore radio button is checked
                {
                    if ((LastNameLetter >= 'P' && LastNameLetter <= 'Z' || LastNameLetter <= 'B')) // This determines what the last name letter is
                        scheduledDatelabel.Text = Day3; // This displays March 31, 2017 in Date Label
                    else // This else statement will put you on the other sophomore day if you dont meet the logic
                        scheduledDatelabel.Text = Day4; // This displays April 3, 2017 in Date Label
                }
                else // This else statment determines if freshman radio button is checked
                {
                    if ((LastNameLetter >= 'P' && LastNameLetter <= 'Z' || LastNameLetter <= 'B'))  /// This determines what the last name letter is
                        scheduledDatelabel.Text = Day5; // This displays April 4, 2017 in Date Label
                    else // This else statment will put you on the other day if you dont meet the logic
                        scheduledDatelabel.Text = Day6; // This displays April 5, 2017 in Date Label
                }
                if (LastNameLetter <= 'B') // Last Name Letter A-B
                    scheduledTimelabel.Text = Time5; // This displays 4:00 PM in Time Label
                else if (LastNameLetter <= 'D') // Last Name Letter C-D
                    scheduledTimelabel.Text = Time1; // This displays 8:30 Am In Time Label
                else if (LastNameLetter <= 'F') // Last Name Letter E-F
                    scheduledTimelabel.Text = Time2; // This displays 10:00 AM In Time Label
                else if (LastNameLetter <= 'I') // Last Name Letter G-I
                    scheduledTimelabel.Text = Time3; // This displays 11:30 AM in Time Label
                else if (LastNameLetter <= 'L') // Last Name Letter J-L
                    scheduledTimelabel.Text = Time4; // This displays 2:00 PM in Time Label
                else if (LastNameLetter <= 'O') // Last Name Letter M-O 
                    scheduledTimelabel.Text = Time5; // This displays 4:00 PM
                else if (LastNameLetter <= 'Q') // Last Name Letter P-Q 
                    scheduledTimelabel.Text = Time1; // This displays 8:30 AM In Time Label
                else if (LastNameLetter <= 'S') // Last Name Letter R-S
                    scheduledTimelabel.Text = Time2; // This displays 10:00 AM In Time Label
                else if (LastNameLetter <= 'V') // Last Name Letter T-V
                    scheduledTimelabel.Text = Time3; // This displays 11:30 AM In Time Label
                else // Last Name W-Z
                    scheduledTimelabel.Text = Time4; // This displays 2:00 PM time in Time Label
            }
        }
    }
}

        

