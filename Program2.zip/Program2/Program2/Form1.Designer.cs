﻿namespace Program2
{
    partial class Program2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.titleLabel = new System.Windows.Forms.Label();
            this.seniorRadiobutton = new System.Windows.Forms.RadioButton();
            this.gradeLeveltitleLabel = new System.Windows.Forms.Label();
            this.juniorRadiobutton = new System.Windows.Forms.RadioButton();
            this.sophomoreRadiobutton = new System.Windows.Forms.RadioButton();
            this.freshmanRadiobutton = new System.Windows.Forms.RadioButton();
            this.lastNameletterTitlelabel = new System.Windows.Forms.Label();
            this.lastNametextBox = new System.Windows.Forms.TextBox();
            this.findOutbutton = new System.Windows.Forms.Button();
            this.dateTitlelabel = new System.Windows.Forms.Label();
            this.timeLabeltitle = new System.Windows.Forms.Label();
            this.scheduledDatelabel = new System.Windows.Forms.Label();
            this.scheduledTimelabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // titleLabel
            // 
            this.titleLabel.AutoSize = true;
            this.titleLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.titleLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.titleLabel.Location = new System.Drawing.Point(104, 64);
            this.titleLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.titleLabel.Name = "titleLabel";
            this.titleLabel.Size = new System.Drawing.Size(649, 53);
            this.titleLabel.TabIndex = 0;
            this.titleLabel.Text = "Fall 2017 Registration Calculator";
            // 
            // seniorRadiobutton
            // 
            this.seniorRadiobutton.AutoSize = true;
            this.seniorRadiobutton.Location = new System.Drawing.Point(37, 254);
            this.seniorRadiobutton.Margin = new System.Windows.Forms.Padding(4);
            this.seniorRadiobutton.Name = "seniorRadiobutton";
            this.seniorRadiobutton.Size = new System.Drawing.Size(123, 35);
            this.seniorRadiobutton.TabIndex = 1;
            this.seniorRadiobutton.TabStop = true;
            this.seniorRadiobutton.Text = "Senior";
            this.seniorRadiobutton.UseVisualStyleBackColor = true;
            // 
            // gradeLeveltitleLabel
            // 
            this.gradeLeveltitleLabel.AutoSize = true;
            this.gradeLeveltitleLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.gradeLeveltitleLabel.Location = new System.Drawing.Point(16, 205);
            this.gradeLeveltitleLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.gradeLeveltitleLabel.Name = "gradeLeveltitleLabel";
            this.gradeLeveltitleLabel.Size = new System.Drawing.Size(246, 33);
            this.gradeLeveltitleLabel.TabIndex = 2;
            this.gradeLeveltitleLabel.Text = "Select Your Grade:";
            // 
            // juniorRadiobutton
            // 
            this.juniorRadiobutton.AutoSize = true;
            this.juniorRadiobutton.Location = new System.Drawing.Point(37, 288);
            this.juniorRadiobutton.Margin = new System.Windows.Forms.Padding(4);
            this.juniorRadiobutton.Name = "juniorRadiobutton";
            this.juniorRadiobutton.Size = new System.Drawing.Size(119, 35);
            this.juniorRadiobutton.TabIndex = 3;
            this.juniorRadiobutton.TabStop = true;
            this.juniorRadiobutton.Text = "Junior";
            this.juniorRadiobutton.UseVisualStyleBackColor = true;
            // 
            // sophomoreRadiobutton
            // 
            this.sophomoreRadiobutton.AutoSize = true;
            this.sophomoreRadiobutton.Location = new System.Drawing.Point(37, 322);
            this.sophomoreRadiobutton.Margin = new System.Windows.Forms.Padding(4);
            this.sophomoreRadiobutton.Name = "sophomoreRadiobutton";
            this.sophomoreRadiobutton.Size = new System.Drawing.Size(184, 35);
            this.sophomoreRadiobutton.TabIndex = 4;
            this.sophomoreRadiobutton.TabStop = true;
            this.sophomoreRadiobutton.Text = "Sophomore";
            this.sophomoreRadiobutton.UseVisualStyleBackColor = true;
            // 
            // freshmanRadiobutton
            // 
            this.freshmanRadiobutton.AutoSize = true;
            this.freshmanRadiobutton.Location = new System.Drawing.Point(37, 353);
            this.freshmanRadiobutton.Margin = new System.Windows.Forms.Padding(4);
            this.freshmanRadiobutton.Name = "freshmanRadiobutton";
            this.freshmanRadiobutton.Size = new System.Drawing.Size(167, 35);
            this.freshmanRadiobutton.TabIndex = 5;
            this.freshmanRadiobutton.TabStop = true;
            this.freshmanRadiobutton.Text = "Freshman";
            this.freshmanRadiobutton.UseVisualStyleBackColor = true;
            // 
            // lastNameletterTitlelabel
            // 
            this.lastNameletterTitlelabel.AutoSize = true;
            this.lastNameletterTitlelabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lastNameletterTitlelabel.Location = new System.Drawing.Point(525, 210);
            this.lastNameletterTitlelabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lastNameletterTitlelabel.Name = "lastNameletterTitlelabel";
            this.lastNameletterTitlelabel.Size = new System.Drawing.Size(329, 33);
            this.lastNameletterTitlelabel.TabIndex = 6;
            this.lastNameletterTitlelabel.Text = "First Letter Of Last Name:";
            // 
            // lastNametextBox
            // 
            this.lastNametextBox.Location = new System.Drawing.Point(525, 254);
            this.lastNametextBox.Margin = new System.Windows.Forms.Padding(4);
            this.lastNametextBox.Name = "lastNametextBox";
            this.lastNametextBox.Size = new System.Drawing.Size(70, 38);
            this.lastNametextBox.TabIndex = 7;
            // 
            // findOutbutton
            // 
            this.findOutbutton.Location = new System.Drawing.Point(140, 459);
            this.findOutbutton.Margin = new System.Windows.Forms.Padding(4);
            this.findOutbutton.Name = "findOutbutton";
            this.findOutbutton.Size = new System.Drawing.Size(576, 88);
            this.findOutbutton.TabIndex = 8;
            this.findOutbutton.Text = "Find Out My Registration";
            this.findOutbutton.UseVisualStyleBackColor = true;
            this.findOutbutton.Click += new System.EventHandler(this.findOutbutton_Click);
            // 
            // dateTitlelabel
            // 
            this.dateTitlelabel.AutoSize = true;
            this.dateTitlelabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.dateTitlelabel.Location = new System.Drawing.Point(28, 626);
            this.dateTitlelabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.dateTitlelabel.Name = "dateTitlelabel";
            this.dateTitlelabel.Size = new System.Drawing.Size(82, 33);
            this.dateTitlelabel.TabIndex = 9;
            this.dateTitlelabel.Text = "Date:";
            // 
            // timeLabeltitle
            // 
            this.timeLabeltitle.AutoSize = true;
            this.timeLabeltitle.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.timeLabeltitle.Location = new System.Drawing.Point(593, 623);
            this.timeLabeltitle.Name = "timeLabeltitle";
            this.timeLabeltitle.Size = new System.Drawing.Size(84, 33);
            this.timeLabeltitle.TabIndex = 10;
            this.timeLabeltitle.Text = "Time:";
            // 
            // scheduledDatelabel
            // 
            this.scheduledDatelabel.AutoSize = true;
            this.scheduledDatelabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.scheduledDatelabel.Location = new System.Drawing.Point(33, 685);
            this.scheduledDatelabel.Name = "scheduledDatelabel";
            this.scheduledDatelabel.Size = new System.Drawing.Size(2, 33);
            this.scheduledDatelabel.TabIndex = 11;
            // 
            // scheduledTimelabel
            // 
            this.scheduledTimelabel.AutoSize = true;
            this.scheduledTimelabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.scheduledTimelabel.Location = new System.Drawing.Point(593, 697);
            this.scheduledTimelabel.Name = "scheduledTimelabel";
            this.scheduledTimelabel.Size = new System.Drawing.Size(2, 33);
            this.scheduledTimelabel.TabIndex = 12;
            // 
            // Program2
            // 
            this.AcceptButton = this.findOutbutton;
            this.AutoScaleDimensions = new System.Drawing.SizeF(16F, 31F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(908, 843);
            this.Controls.Add(this.scheduledTimelabel);
            this.Controls.Add(this.scheduledDatelabel);
            this.Controls.Add(this.timeLabeltitle);
            this.Controls.Add(this.dateTitlelabel);
            this.Controls.Add(this.findOutbutton);
            this.Controls.Add(this.lastNametextBox);
            this.Controls.Add(this.lastNameletterTitlelabel);
            this.Controls.Add(this.freshmanRadiobutton);
            this.Controls.Add(this.sophomoreRadiobutton);
            this.Controls.Add(this.juniorRadiobutton);
            this.Controls.Add(this.gradeLeveltitleLabel);
            this.Controls.Add(this.seniorRadiobutton);
            this.Controls.Add(this.titleLabel);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Program2";
            this.Text = "Program2";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label titleLabel;
        private System.Windows.Forms.RadioButton seniorRadiobutton;
        private System.Windows.Forms.Label gradeLeveltitleLabel;
        private System.Windows.Forms.RadioButton juniorRadiobutton;
        private System.Windows.Forms.RadioButton sophomoreRadiobutton;
        private System.Windows.Forms.RadioButton freshmanRadiobutton;
        private System.Windows.Forms.Label lastNameletterTitlelabel;
        private System.Windows.Forms.TextBox lastNametextBox;
        private System.Windows.Forms.Button findOutbutton;
        private System.Windows.Forms.Label dateTitlelabel;
        private System.Windows.Forms.Label timeLabeltitle;
        private System.Windows.Forms.Label scheduledDatelabel;
        private System.Windows.Forms.Label scheduledTimelabel;
    }
}

