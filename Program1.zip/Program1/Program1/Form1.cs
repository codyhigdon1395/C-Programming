﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Program1
{
    public partial class program1Form : Form
    {
        public program1Form()
        {
            InitializeComponent();
        }

        private void jobEstimatebutton_Click(object sender, EventArgs e)
        {
            const float feet_Per_gallon = 330F; // A constant used for later equations
            const float hours_Per_gallon = 6.0F; // A constant used for later equations
            const float price_Per_hour = 10.5F; // A constant used for later equations

            float totalSquarefeet; // A float used for later equations
            float totalGallons; // A float used for later equations
            float totalPaintcost; // A float used for later equations
            float laborHours; // A float used for later equations
            float totalLaborcost; // A float used for later equations
            float totalPaintjobEstimate; // A float used for later equations.

            float squareFeettextBoxParse; // A parse to help the calculation
            float numberOfcoatsTextboxParse; // A parse to help the calculation
            float costOfpaintTextboxParse; // A parse to help the calculation

            squareFeettextBoxParse = float.Parse(squareFeettextBox.Text); // This command shows what to display
            numberOfcoatsTextboxParse = float.Parse(numberOfcoatsTextbox.Text); // This command shows what to display
            costOfpaintTextboxParse = float.Parse(costOfpaintTextbox.Text); // This command shows to what to display


            totalSquarefeet = squareFeettextBoxParse * numberOfcoatsTextboxParse; // A calculation to show total square feet
            finalSquarefeetLabel.Text = totalSquarefeet.ToString("f"); // Converts over to number in the label

            totalGallons = (float)Math.Ceiling(totalSquarefeet / feet_Per_gallon); // A calculation to show total gallons of paint
            finalGallonslabel.Text = totalGallons.ToString("f"); // Converts over to gallons of pain used in the label

            laborHours = hours_Per_gallon * (totalSquarefeet / feet_Per_gallon); // A calculation to show total labor hours used
            finalLaborhoursLabel.Text = laborHours.ToString("f1"); // Converts labor hours over to a text in the label

            totalPaintcost = costOfpaintTextboxParse * totalGallons; // A calculation to show total paint cost
            finalPaintcostLabel.Text = totalPaintcost.ToString("c"); // Converts Final cost to a nunber in the label

            totalLaborcost = laborHours * price_Per_hour; // A calculation to show total cost of labor
            finalLaborcostLabel.Text = totalLaborcost.ToString("c"); // Converts The Label to a number in the box for total cost

            totalPaintjobEstimate = totalLaborcost + totalPaintcost; // A Calculation for Total Job Cost
            finalPaintjobCost.Text = totalPaintjobEstimate.ToString("c"); // Converts the label over to a calculated total
        }

    }
}
