﻿namespace Program1
{
    partial class program1Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.squareFeetlabel = new System.Windows.Forms.Label();
            this.numberOfCoatsLabel = new System.Windows.Forms.Label();
            this.costOfpaintLabel = new System.Windows.Forms.Label();
            this.squareFeettextBox = new System.Windows.Forms.TextBox();
            this.numberOfcoatsTextbox = new System.Windows.Forms.TextBox();
            this.costOfpaintTextbox = new System.Windows.Forms.TextBox();
            this.jobEstimatebutton = new System.Windows.Forms.Button();
            this.totalSquarefeetLabel = new System.Windows.Forms.Label();
            this.totalGallonslabel = new System.Windows.Forms.Label();
            this.totalPaintCostlabel = new System.Windows.Forms.Label();
            this.laborHourslabel = new System.Windows.Forms.Label();
            this.totalLaborcostLabel = new System.Windows.Forms.Label();
            this.totalPaintjobEstimate = new System.Windows.Forms.Label();
            this.finalSquarefeetLabel = new System.Windows.Forms.Label();
            this.finalGallonslabel = new System.Windows.Forms.Label();
            this.finalPaintcostLabel = new System.Windows.Forms.Label();
            this.finalLaborhoursLabel = new System.Windows.Forms.Label();
            this.finalLaborcostLabel = new System.Windows.Forms.Label();
            this.finalPaintjobCost = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // squareFeetlabel
            // 
            this.squareFeetlabel.AutoSize = true;
            this.squareFeetlabel.Location = new System.Drawing.Point(33, 72);
            this.squareFeetlabel.Name = "squareFeetlabel";
            this.squareFeetlabel.Size = new System.Drawing.Size(136, 25);
            this.squareFeetlabel.TabIndex = 0;
            this.squareFeetlabel.Text = "Square Feet:";
            // 
            // numberOfCoatsLabel
            // 
            this.numberOfCoatsLabel.AutoSize = true;
            this.numberOfCoatsLabel.Location = new System.Drawing.Point(33, 154);
            this.numberOfCoatsLabel.Name = "numberOfCoatsLabel";
            this.numberOfCoatsLabel.Size = new System.Drawing.Size(183, 25);
            this.numberOfCoatsLabel.TabIndex = 1;
            this.numberOfCoatsLabel.Text = "Number Of Coats:";
            // 
            // costOfpaintLabel
            // 
            this.costOfpaintLabel.AutoSize = true;
            this.costOfpaintLabel.Location = new System.Drawing.Point(33, 239);
            this.costOfpaintLabel.Name = "costOfpaintLabel";
            this.costOfpaintLabel.Size = new System.Drawing.Size(145, 25);
            this.costOfpaintLabel.TabIndex = 2;
            this.costOfpaintLabel.Text = "Cost Of Paint:";
            // 
            // squareFeettextBox
            // 
            this.squareFeettextBox.Location = new System.Drawing.Point(222, 72);
            this.squareFeettextBox.Name = "squareFeettextBox";
            this.squareFeettextBox.Size = new System.Drawing.Size(188, 31);
            this.squareFeettextBox.TabIndex = 3;
            // 
            // numberOfcoatsTextbox
            // 
            this.numberOfcoatsTextbox.Location = new System.Drawing.Point(222, 154);
            this.numberOfcoatsTextbox.Name = "numberOfcoatsTextbox";
            this.numberOfcoatsTextbox.Size = new System.Drawing.Size(188, 31);
            this.numberOfcoatsTextbox.TabIndex = 4;
            // 
            // costOfpaintTextbox
            // 
            this.costOfpaintTextbox.Location = new System.Drawing.Point(222, 239);
            this.costOfpaintTextbox.Name = "costOfpaintTextbox";
            this.costOfpaintTextbox.Size = new System.Drawing.Size(188, 31);
            this.costOfpaintTextbox.TabIndex = 5;
            // 
            // jobEstimatebutton
            // 
            this.jobEstimatebutton.Location = new System.Drawing.Point(67, 342);
            this.jobEstimatebutton.Name = "jobEstimatebutton";
            this.jobEstimatebutton.Size = new System.Drawing.Size(342, 122);
            this.jobEstimatebutton.TabIndex = 6;
            this.jobEstimatebutton.Text = "Get Job Estimate";
            this.jobEstimatebutton.UseVisualStyleBackColor = true;
            this.jobEstimatebutton.Click += new System.EventHandler(this.jobEstimatebutton_Click);
            // 
            // totalSquarefeetLabel
            // 
            this.totalSquarefeetLabel.AutoSize = true;
            this.totalSquarefeetLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.totalSquarefeetLabel.Location = new System.Drawing.Point(480, 72);
            this.totalSquarefeetLabel.Name = "totalSquarefeetLabel";
            this.totalSquarefeetLabel.Size = new System.Drawing.Size(186, 27);
            this.totalSquarefeetLabel.TabIndex = 7;
            this.totalSquarefeetLabel.Text = "Total Sqaure Feet";
            // 
            // totalGallonslabel
            // 
            this.totalGallonslabel.AutoSize = true;
            this.totalGallonslabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.totalGallonslabel.Location = new System.Drawing.Point(480, 143);
            this.totalGallonslabel.Name = "totalGallonslabel";
            this.totalGallonslabel.Size = new System.Drawing.Size(147, 27);
            this.totalGallonslabel.TabIndex = 8;
            this.totalGallonslabel.Text = "Total Gallons:";
            // 
            // totalPaintCostlabel
            // 
            this.totalPaintCostlabel.AutoSize = true;
            this.totalPaintCostlabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.totalPaintCostlabel.Location = new System.Drawing.Point(480, 223);
            this.totalPaintCostlabel.Name = "totalPaintCostlabel";
            this.totalPaintCostlabel.Size = new System.Drawing.Size(173, 27);
            this.totalPaintCostlabel.TabIndex = 9;
            this.totalPaintCostlabel.Text = "Total Paint Cost:";
            // 
            // laborHourslabel
            // 
            this.laborHourslabel.AutoSize = true;
            this.laborHourslabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.laborHourslabel.Location = new System.Drawing.Point(480, 287);
            this.laborHourslabel.Name = "laborHourslabel";
            this.laborHourslabel.Size = new System.Drawing.Size(138, 27);
            this.laborHourslabel.TabIndex = 10;
            this.laborHourslabel.Text = "Labor Hours:";
            // 
            // totalLaborcostLabel
            // 
            this.totalLaborcostLabel.AutoSize = true;
            this.totalLaborcostLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.totalLaborcostLabel.Location = new System.Drawing.Point(480, 353);
            this.totalLaborcostLabel.Name = "totalLaborcostLabel";
            this.totalLaborcostLabel.Size = new System.Drawing.Size(179, 27);
            this.totalLaborcostLabel.TabIndex = 11;
            this.totalLaborcostLabel.Text = "Total Labor Cost:";
            // 
            // totalPaintjobEstimate
            // 
            this.totalPaintjobEstimate.AutoSize = true;
            this.totalPaintjobEstimate.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.totalPaintjobEstimate.Location = new System.Drawing.Point(475, 427);
            this.totalPaintjobEstimate.Name = "totalPaintjobEstimate";
            this.totalPaintjobEstimate.Size = new System.Drawing.Size(253, 27);
            this.totalPaintjobEstimate.TabIndex = 12;
            this.totalPaintjobEstimate.Text = "Total Paint Job Estimate:";
            // 
            // finalSquarefeetLabel
            // 
            this.finalSquarefeetLabel.AutoSize = true;
            this.finalSquarefeetLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.finalSquarefeetLabel.Location = new System.Drawing.Point(715, 76);
            this.finalSquarefeetLabel.Name = "finalSquarefeetLabel";
            this.finalSquarefeetLabel.Size = new System.Drawing.Size(2, 27);
            this.finalSquarefeetLabel.TabIndex = 13;
            // 
            // finalGallonslabel
            // 
            this.finalGallonslabel.AutoSize = true;
            this.finalGallonslabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.finalGallonslabel.Location = new System.Drawing.Point(715, 143);
            this.finalGallonslabel.Name = "finalGallonslabel";
            this.finalGallonslabel.Size = new System.Drawing.Size(2, 27);
            this.finalGallonslabel.TabIndex = 14;
            // 
            // finalPaintcostLabel
            // 
            this.finalPaintcostLabel.AutoSize = true;
            this.finalPaintcostLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.finalPaintcostLabel.Location = new System.Drawing.Point(715, 223);
            this.finalPaintcostLabel.Name = "finalPaintcostLabel";
            this.finalPaintcostLabel.Size = new System.Drawing.Size(2, 27);
            this.finalPaintcostLabel.TabIndex = 15;
            // 
            // finalLaborhoursLabel
            // 
            this.finalLaborhoursLabel.AutoSize = true;
            this.finalLaborhoursLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.finalLaborhoursLabel.Location = new System.Drawing.Point(715, 289);
            this.finalLaborhoursLabel.Name = "finalLaborhoursLabel";
            this.finalLaborhoursLabel.Size = new System.Drawing.Size(2, 27);
            this.finalLaborhoursLabel.TabIndex = 16;
            // 
            // finalLaborcostLabel
            // 
            this.finalLaborcostLabel.AutoSize = true;
            this.finalLaborcostLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.finalLaborcostLabel.Location = new System.Drawing.Point(710, 353);
            this.finalLaborcostLabel.Name = "finalLaborcostLabel";
            this.finalLaborcostLabel.Size = new System.Drawing.Size(2, 27);
            this.finalLaborcostLabel.TabIndex = 17;
            // 
            // finalPaintjobCost
            // 
            this.finalPaintjobCost.AutoSize = true;
            this.finalPaintjobCost.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.finalPaintjobCost.Location = new System.Drawing.Point(768, 429);
            this.finalPaintjobCost.Name = "finalPaintjobCost";
            this.finalPaintjobCost.Size = new System.Drawing.Size(2, 27);
            this.finalPaintjobCost.TabIndex = 18;
            // 
            // program1Form
            // 
            this.AcceptButton = this.jobEstimatebutton;
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(951, 591);
            this.Controls.Add(this.finalPaintjobCost);
            this.Controls.Add(this.finalLaborcostLabel);
            this.Controls.Add(this.finalLaborhoursLabel);
            this.Controls.Add(this.finalPaintcostLabel);
            this.Controls.Add(this.finalGallonslabel);
            this.Controls.Add(this.finalSquarefeetLabel);
            this.Controls.Add(this.totalPaintjobEstimate);
            this.Controls.Add(this.totalLaborcostLabel);
            this.Controls.Add(this.laborHourslabel);
            this.Controls.Add(this.totalPaintCostlabel);
            this.Controls.Add(this.totalGallonslabel);
            this.Controls.Add(this.totalSquarefeetLabel);
            this.Controls.Add(this.jobEstimatebutton);
            this.Controls.Add(this.costOfpaintTextbox);
            this.Controls.Add(this.numberOfcoatsTextbox);
            this.Controls.Add(this.squareFeettextBox);
            this.Controls.Add(this.costOfpaintLabel);
            this.Controls.Add(this.numberOfCoatsLabel);
            this.Controls.Add(this.squareFeetlabel);
            this.Name = "program1Form";
            this.Text = "Program1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label squareFeetlabel;
        private System.Windows.Forms.Label numberOfCoatsLabel;
        private System.Windows.Forms.Label costOfpaintLabel;
        private System.Windows.Forms.TextBox squareFeettextBox;
        private System.Windows.Forms.TextBox numberOfcoatsTextbox;
        private System.Windows.Forms.TextBox costOfpaintTextbox;
        private System.Windows.Forms.Button jobEstimatebutton;
        private System.Windows.Forms.Label totalSquarefeetLabel;
        private System.Windows.Forms.Label totalGallonslabel;
        private System.Windows.Forms.Label totalPaintCostlabel;
        private System.Windows.Forms.Label laborHourslabel;
        private System.Windows.Forms.Label totalLaborcostLabel;
        private System.Windows.Forms.Label totalPaintjobEstimate;
        private System.Windows.Forms.Label finalSquarefeetLabel;
        private System.Windows.Forms.Label finalGallonslabel;
        private System.Windows.Forms.Label finalPaintcostLabel;
        private System.Windows.Forms.Label finalLaborhoursLabel;
        private System.Windows.Forms.Label finalLaborcostLabel;
        private System.Windows.Forms.Label finalPaintjobCost;
    }
}

