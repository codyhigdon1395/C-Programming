﻿/* B8978
 * Program #4
 * CIS 199-02
 * This program is designed for a package company to determine costs.
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Program_4
{
    class GroundPackage // This forms the package class.
    { // These are dec,ared variables
        private int _originZip; 
        private int _destZip; 
        private double _length; 
        private double _width;
        private double _height; 
        private double _weight;

        public GroundPackage(int startingZipcode, int endingZipcode, double packageLength, double packageWidth, double packageHeight, double packageWeight) // This describes how ground package is set up.
        { //These set up the values for the constructor
            OriginZip = startingZipcode; 
            DestinationZip = endingZipcode; 
            _length = packageLength; 
            _width = packageWidth; 
            _height = packageHeight; 
            _weight = packageWeight; 
        }
        public int OriginZip // Orgin Zip Property
        {
            get

            {
                return _originZip; // This returns the orgin zipcode
            }
            set 
            {
                if (value >= 00000 && value <= 99999) // Value has to be with this prarameter
                    _originZip = value; // This gives you the value entered
                else
                    _originZip = 40202; // Elese it its UofL's zipcode
            }
        }
        public int DestinationZip // Destination Zip Property
        {
            get
            {
                return _destZip; // This returns destination zip code
            }
            set
            {
                if (value >= 00000 && value <= 99999)

                    _destZip = value; // This makes value equal to the imputed
                else
                    _destZip = 40292; // This reverts it baqck UofL's zip code if not filled out
            }
        }
        public int ZoneDistance // This determines xone destination
        {
            get

            {
                return Math.Abs((DestinationZip / 10000) - (OriginZip / 10000)); // This the calculates zone distance
            }
        }
        public double CalcCost() // This method calculates the cost
        {
            double CalcCost = (.20 * (_length + _width + _height)) + (.5 * (ZoneDistance + 1) * _weight); // This math for calculating cost.
               return CalcCost; // This returns CalcCost
        }
        public override string ToString()
        { // This sets up how the infornation is displayed when accessed from the listbox.
            return string.Format("Origin Zip: " + OriginZip.ToString() + "{0}" +
                "Destination Zip: " + DestinationZip.ToString() + "{1}" +
                "Length: " + _length.ToString("F2") + " in" + "{2}" +
                "Width: " + _width.ToString("F2") + " in" + "{3}" +
                "Height: " + _height.ToString("F2") + " in" + "{4}" +
                "Weight: " + _weight.ToString("F2") + " lb(s)" + "{5}" +
                "Total Cost: " + CalcCost().ToString("C") + "{6}",
                Environment.NewLine, Environment.NewLine, Environment.NewLine, Environment.NewLine,
                Environment.NewLine, Environment.NewLine, Environment.NewLine); 
        }
    }
}
        
    

