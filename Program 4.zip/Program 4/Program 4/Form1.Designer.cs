﻿namespace Program_4
{
    partial class Program4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.originZiptitleLabel = new System.Windows.Forms.Label();
            this.destinationZiptitleLabel = new System.Windows.Forms.Label();
            this.lengthTitlelabel = new System.Windows.Forms.Label();
            this.widthTitlelabel = new System.Windows.Forms.Label();
            this.heightTitlelabel = new System.Windows.Forms.Label();
            this.weightTitlelabel = new System.Windows.Forms.Label();
            this.originZiptextBox = new System.Windows.Forms.TextBox();
            this.destinationZiptextBox = new System.Windows.Forms.TextBox();
            this.lengthTextbox = new System.Windows.Forms.TextBox();
            this.widthTextbox = new System.Windows.Forms.TextBox();
            this.heightTextbox = new System.Windows.Forms.TextBox();
            this.weightTextbox = new System.Windows.Forms.TextBox();
            this.addGroundpackageButton = new System.Windows.Forms.Button();
            this.packageOutputlistBox = new System.Windows.Forms.ListBox();
            this.packageDetailsbutton = new System.Windows.Forms.Button();
            this.sendTouoflButton = new System.Windows.Forms.Button();
            this.sendFromuoflButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // originZiptitleLabel
            // 
            this.originZiptitleLabel.AutoSize = true;
            this.originZiptitleLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.originZiptitleLabel.Location = new System.Drawing.Point(34, 57);
            this.originZiptitleLabel.Name = "originZiptitleLabel";
            this.originZiptitleLabel.Size = new System.Drawing.Size(113, 27);
            this.originZiptitleLabel.TabIndex = 0;
            this.originZiptitleLabel.Text = "Origin Zip:";
            // 
            // destinationZiptitleLabel
            // 
            this.destinationZiptitleLabel.AutoSize = true;
            this.destinationZiptitleLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.destinationZiptitleLabel.Location = new System.Drawing.Point(34, 116);
            this.destinationZiptitleLabel.Name = "destinationZiptitleLabel";
            this.destinationZiptitleLabel.Size = new System.Drawing.Size(164, 27);
            this.destinationZiptitleLabel.TabIndex = 1;
            this.destinationZiptitleLabel.Text = "Destination Zip:";
            // 
            // lengthTitlelabel
            // 
            this.lengthTitlelabel.AutoSize = true;
            this.lengthTitlelabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lengthTitlelabel.Location = new System.Drawing.Point(34, 182);
            this.lengthTitlelabel.Name = "lengthTitlelabel";
            this.lengthTitlelabel.Size = new System.Drawing.Size(86, 27);
            this.lengthTitlelabel.TabIndex = 2;
            this.lengthTitlelabel.Text = "Length:";
            // 
            // widthTitlelabel
            // 
            this.widthTitlelabel.AutoSize = true;
            this.widthTitlelabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.widthTitlelabel.Location = new System.Drawing.Point(33, 254);
            this.widthTitlelabel.Name = "widthTitlelabel";
            this.widthTitlelabel.Size = new System.Drawing.Size(75, 27);
            this.widthTitlelabel.TabIndex = 3;
            this.widthTitlelabel.Text = "Width:";
            // 
            // heightTitlelabel
            // 
            this.heightTitlelabel.AutoSize = true;
            this.heightTitlelabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.heightTitlelabel.Location = new System.Drawing.Point(29, 329);
            this.heightTitlelabel.Name = "heightTitlelabel";
            this.heightTitlelabel.Size = new System.Drawing.Size(82, 27);
            this.heightTitlelabel.TabIndex = 4;
            this.heightTitlelabel.Text = "Height:";
            // 
            // weightTitlelabel
            // 
            this.weightTitlelabel.AutoSize = true;
            this.weightTitlelabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.weightTitlelabel.Location = new System.Drawing.Point(29, 409);
            this.weightTitlelabel.Name = "weightTitlelabel";
            this.weightTitlelabel.Size = new System.Drawing.Size(87, 27);
            this.weightTitlelabel.TabIndex = 5;
            this.weightTitlelabel.Text = "Weight:";
            // 
            // originZiptextBox
            // 
            this.originZiptextBox.Location = new System.Drawing.Point(227, 57);
            this.originZiptextBox.Name = "originZiptextBox";
            this.originZiptextBox.Size = new System.Drawing.Size(286, 31);
            this.originZiptextBox.TabIndex = 6;
            // 
            // destinationZiptextBox
            // 
            this.destinationZiptextBox.Location = new System.Drawing.Point(227, 112);
            this.destinationZiptextBox.Name = "destinationZiptextBox";
            this.destinationZiptextBox.Size = new System.Drawing.Size(286, 31);
            this.destinationZiptextBox.TabIndex = 7;
            // 
            // lengthTextbox
            // 
            this.lengthTextbox.Location = new System.Drawing.Point(227, 182);
            this.lengthTextbox.Name = "lengthTextbox";
            this.lengthTextbox.Size = new System.Drawing.Size(286, 31);
            this.lengthTextbox.TabIndex = 8;
            // 
            // widthTextbox
            // 
            this.widthTextbox.Location = new System.Drawing.Point(227, 254);
            this.widthTextbox.Name = "widthTextbox";
            this.widthTextbox.Size = new System.Drawing.Size(286, 31);
            this.widthTextbox.TabIndex = 9;
            // 
            // heightTextbox
            // 
            this.heightTextbox.Location = new System.Drawing.Point(227, 329);
            this.heightTextbox.Name = "heightTextbox";
            this.heightTextbox.Size = new System.Drawing.Size(286, 31);
            this.heightTextbox.TabIndex = 10;
            // 
            // weightTextbox
            // 
            this.weightTextbox.Location = new System.Drawing.Point(227, 405);
            this.weightTextbox.Name = "weightTextbox";
            this.weightTextbox.Size = new System.Drawing.Size(286, 31);
            this.weightTextbox.TabIndex = 11;
            // 
            // addGroundpackageButton
            // 
            this.addGroundpackageButton.Location = new System.Drawing.Point(227, 472);
            this.addGroundpackageButton.Name = "addGroundpackageButton";
            this.addGroundpackageButton.Size = new System.Drawing.Size(286, 63);
            this.addGroundpackageButton.TabIndex = 12;
            this.addGroundpackageButton.Text = "Add Ground Package";
            this.addGroundpackageButton.UseVisualStyleBackColor = true;
            this.addGroundpackageButton.Click += new System.EventHandler(this.addGroundpackageButton_Click);
            // 
            // packageOutputlistBox
            // 
            this.packageOutputlistBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.packageOutputlistBox.FormattingEnabled = true;
            this.packageOutputlistBox.ItemHeight = 25;
            this.packageOutputlistBox.Location = new System.Drawing.Point(667, 90);
            this.packageOutputlistBox.Name = "packageOutputlistBox";
            this.packageOutputlistBox.Size = new System.Drawing.Size(340, 327);
            this.packageOutputlistBox.TabIndex = 13;
            // 
            // packageDetailsbutton
            // 
            this.packageDetailsbutton.Location = new System.Drawing.Point(667, 441);
            this.packageDetailsbutton.Name = "packageDetailsbutton";
            this.packageDetailsbutton.Size = new System.Drawing.Size(340, 41);
            this.packageDetailsbutton.TabIndex = 14;
            this.packageDetailsbutton.Text = "Package Details";
            this.packageDetailsbutton.UseVisualStyleBackColor = true;
            this.packageDetailsbutton.Click += new System.EventHandler(this.packageDetailsbutton_Click);
            // 
            // sendTouoflButton
            // 
            this.sendTouoflButton.Location = new System.Drawing.Point(667, 494);
            this.sendTouoflButton.Name = "sendTouoflButton";
            this.sendTouoflButton.Size = new System.Drawing.Size(339, 41);
            this.sendTouoflButton.TabIndex = 15;
            this.sendTouoflButton.Text = "Send To UofL";
            this.sendTouoflButton.UseVisualStyleBackColor = true;
            this.sendTouoflButton.Click += new System.EventHandler(this.sendTouoflButton_Click);
            // 
            // sendFromuoflButton
            // 
            this.sendFromuoflButton.Location = new System.Drawing.Point(667, 552);
            this.sendFromuoflButton.Name = "sendFromuoflButton";
            this.sendFromuoflButton.Size = new System.Drawing.Size(340, 37);
            this.sendFromuoflButton.TabIndex = 16;
            this.sendFromuoflButton.Text = "Send From UofL";
            this.sendFromuoflButton.UseVisualStyleBackColor = true;
            this.sendFromuoflButton.Click += new System.EventHandler(this.sendFromuoflButton_Click);
            // 
            // Program4
            // 
            this.AcceptButton = this.addGroundpackageButton;
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1092, 658);
            this.Controls.Add(this.sendFromuoflButton);
            this.Controls.Add(this.sendTouoflButton);
            this.Controls.Add(this.packageDetailsbutton);
            this.Controls.Add(this.packageOutputlistBox);
            this.Controls.Add(this.addGroundpackageButton);
            this.Controls.Add(this.weightTextbox);
            this.Controls.Add(this.heightTextbox);
            this.Controls.Add(this.widthTextbox);
            this.Controls.Add(this.lengthTextbox);
            this.Controls.Add(this.destinationZiptextBox);
            this.Controls.Add(this.originZiptextBox);
            this.Controls.Add(this.weightTitlelabel);
            this.Controls.Add(this.heightTitlelabel);
            this.Controls.Add(this.widthTitlelabel);
            this.Controls.Add(this.lengthTitlelabel);
            this.Controls.Add(this.destinationZiptitleLabel);
            this.Controls.Add(this.originZiptitleLabel);
            this.Name = "Program4";
            this.Text = "Program 4";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label originZiptitleLabel;
        private System.Windows.Forms.Label destinationZiptitleLabel;
        private System.Windows.Forms.Label lengthTitlelabel;
        private System.Windows.Forms.Label widthTitlelabel;
        private System.Windows.Forms.Label heightTitlelabel;
        private System.Windows.Forms.Label weightTitlelabel;
        private System.Windows.Forms.TextBox originZiptextBox;
        private System.Windows.Forms.TextBox destinationZiptextBox;
        private System.Windows.Forms.TextBox lengthTextbox;
        private System.Windows.Forms.TextBox widthTextbox;
        private System.Windows.Forms.TextBox heightTextbox;
        private System.Windows.Forms.TextBox weightTextbox;
        private System.Windows.Forms.Button addGroundpackageButton;
        private System.Windows.Forms.ListBox packageOutputlistBox;
        private System.Windows.Forms.Button packageDetailsbutton;
        private System.Windows.Forms.Button sendTouoflButton;
        private System.Windows.Forms.Button sendFromuoflButton;
    }
}

