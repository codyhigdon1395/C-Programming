﻿/* B8978
 * Program #4
 * CIS 199-02
 * This program is designed for a package company to determine costs.
 */
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Program_4
{
    public partial class Program4 : Form
    {
        public Program4()
        {
            InitializeComponent();
        }
        private List<GroundPackage> packageList = new List<GroundPackage>(); // This holds the list for package

        private bool ValidateGroundPackage(out int origin, out int destination, out double length, out double width, out double height, out double weight) // This validates the package class
        {
            bool validPackage= false; // This tests to see if it a true statement

            origin = destination = 0; // The destination is always 0

            length = width = height = weight = 0; // This sets everything to zero

            if (int.TryParse(originZiptextBox.Text, out origin)) // This parses out origin zip code 
            {
                if (int.TryParse(destinationZiptextBox.Text, out destination)) // This parses out destination zip code
                {
                    if (double.TryParse(lengthTextbox.Text, out length) && (length >= 0)) // This parses out length and makes sure it's not zero
                    {
                        if (double.TryParse(widthTextbox.Text, out width) && (width >= 0)) // This parses out width and makes sure it's not zero
                        {
                            if (double.TryParse(heightTextbox.Text, out height) && (height >= 0)) // This parses out height and makes sure it's not zero
                            {
                                if (double.TryParse(weightTextbox.Text, out weight) && (weight >= 0)) // This parses out weight and makes sure it's not zero
                                {
                                    validPackage = true; // This show if the information is true
                                }
                                else MessageBox.Show("Invalid Package Weight!"); // This displays if weight is incorrect
                            }
                            else MessageBox.Show("Invalid Package Height!"); //This displays if height is incorrect
                        }
                        else MessageBox.Show("Invalid Package Width!"); // This displays if width is incorrect
                    }
                    else MessageBox.Show("Invalid Package Length!"); // This displays if length is incorrect
                }
                else MessageBox.Show("Invalid Ending Package Zip Code!"); // This displays if ending package zip code is incorrect
            }
            else MessageBox.Show("Invalid Beginning Package Zip Code!"); // This displays if beginning zip code is incorrect
            return validPackage;
        }
        // Preconditions: None
        // PostConditions This adds an item to the list.
        private void addGroundpackageButton_Click(object sender, EventArgs e) // This intiates adding package to the list
        {
            { 
                GroundPackage package; // This declares the class
                int originZip; // This declares origin zip
                int destZip; // This declares destination zip
                double length; // This declares package length
                double width; // This declares package width
                double height; // This declares package height
                double weight; // This declares package weight
                if (ValidateGroundPackage(out originZip, out destZip, out length, out width, out height, out weight)) // This gets the package and it makes sure all valid if true
                {
                    package = new GroundPackage(originZip, destZip, length, width, height, weight); // This creates package with the values
                    packageList.Add(package); // This adds to the list box
                    packageOutputlistBox.Items.Add(package.CalcCost().ToString("C")); // This converts the output to currency format
                    // This clears all textboxes.
                    originZiptextBox.Clear();
                    destinationZiptextBox.Clear();
                    lengthTextbox.Clear();
                    widthTextbox.Clear();
                    heightTextbox.Clear();
                    weightTextbox.Clear();
                }
            }
        }
        // Preconditions: This cannot have anything less than 0
        // PostConditions: This will display package information if there is items in the listbox
        private void packageDetailsbutton_Click(object sender, EventArgs e) // This is the click event for package information.
        {
            {
                int packageIndex; // This declares the package index
                packageIndex = packageOutputlistBox.SelectedIndex; // This initilazies package selection
                if (packageIndex >= 0)
                { 
                   MessageBox.Show(packageList[packageIndex].ToString()); // This shows the packages in the listbox
                }
            }
        }
        // Preconditions: This will change destination zipcode to 40292
        // Postconidtions: This will not change if not selected
        private void sendTouoflButton_Click(object sender, EventArgs e)
        {
            {
                int packageIndex;

                packageIndex = packageOutputlistBox.SelectedIndex; // This initilazies package selection

                if (packageIndex >= 0)
                {
                    packageList[packageIndex].DestinationZip = 40292; // This makes destination zipcode 40292
                    packageOutputlistBox.Items[packageIndex] = packageList[packageIndex].CalcCost().ToString("C"); // This shows the price in the list box from changing destination zipcode
                    MessageBox.Show("The Destination Zip Code has been updated!!"); // This displays to show destination zip has been changed
                }
                else
                    MessageBox.Show("Please Choose The Package!!"); // This pops up if package wasnt selected
            }                                                                           
        }
        // Preconditions: This will change beginning zipcode to 40292
        // Postconidtions: This will not change if not selected
        private void sendFromuoflButton_Click(object sender, EventArgs e)
        {
            {
                int packageIndex; 
                packageIndex = packageOutputlistBox.SelectedIndex; // This initializies package output
                if (packageIndex >= 0) // This makes sure there is a package in list box
                {
                    packageList[packageIndex].OriginZip = 40292; // This changes beginning zip to 40292
                    packageOutputlistBox.Items[packageIndex] = packageList[packageIndex].CalcCost().ToString("C"); // This displays the cost from changing begining zipcode
                    MessageBox.Show("The Starting Zip Code has been updated!!"); // This displays if Starting Zip Code is changed
                }
                else
                    MessageBox.Show("Please Choose The Package"); // This displays if the package isnt selected.
            }
        }
    }
}
