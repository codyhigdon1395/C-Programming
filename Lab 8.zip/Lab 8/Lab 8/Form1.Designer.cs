﻿namespace Lab_8
{
    partial class Lab8
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.monthNumbertitleLabel = new System.Windows.Forms.Label();
            this.monthNumbertextBox = new System.Windows.Forms.TextBox();
            this.monthOutputlabel = new System.Windows.Forms.Label();
            this.lookUpbutton = new System.Windows.Forms.Button();
            this.lanuageGroupbox = new System.Windows.Forms.GroupBox();
            this.englishRadioButton = new System.Windows.Forms.RadioButton();
            this.spanishRadiobutton = new System.Windows.Forms.RadioButton();
            this.italianRadiobutton = new System.Windows.Forms.RadioButton();
            this.lanuageGroupbox.SuspendLayout();
            this.SuspendLayout();
            // 
            // monthNumbertitleLabel
            // 
            this.monthNumbertitleLabel.AutoSize = true;
            this.monthNumbertitleLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.monthNumbertitleLabel.Location = new System.Drawing.Point(59, 72);
            this.monthNumbertitleLabel.Name = "monthNumbertitleLabel";
            this.monthNumbertitleLabel.Size = new System.Drawing.Size(155, 27);
            this.monthNumbertitleLabel.TabIndex = 0;
            this.monthNumbertitleLabel.Text = "Month Number";
            // 
            // monthNumbertextBox
            // 
            this.monthNumbertextBox.Location = new System.Drawing.Point(286, 69);
            this.monthNumbertextBox.Name = "monthNumbertextBox";
            this.monthNumbertextBox.Size = new System.Drawing.Size(113, 31);
            this.monthNumbertextBox.TabIndex = 1;
            // 
            // monthOutputlabel
            // 
            this.monthOutputlabel.AutoSize = true;
            this.monthOutputlabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.monthOutputlabel.Location = new System.Drawing.Point(59, 373);
            this.monthOutputlabel.Name = "monthOutputlabel";
            this.monthOutputlabel.Size = new System.Drawing.Size(2, 27);
            this.monthOutputlabel.TabIndex = 6;
            // 
            // lookUpbutton
            // 
            this.lookUpbutton.Location = new System.Drawing.Point(45, 479);
            this.lookUpbutton.Name = "lookUpbutton";
            this.lookUpbutton.Size = new System.Drawing.Size(354, 53);
            this.lookUpbutton.TabIndex = 7;
            this.lookUpbutton.Text = "Look Up";
            this.lookUpbutton.UseVisualStyleBackColor = true;
            this.lookUpbutton.Click += new System.EventHandler(this.lookUpbutton_Click);
            // 
            // lanuageGroupbox
            // 
            this.lanuageGroupbox.Controls.Add(this.italianRadiobutton);
            this.lanuageGroupbox.Controls.Add(this.spanishRadiobutton);
            this.lanuageGroupbox.Controls.Add(this.englishRadioButton);
            this.lanuageGroupbox.Location = new System.Drawing.Point(64, 131);
            this.lanuageGroupbox.Name = "lanuageGroupbox";
            this.lanuageGroupbox.Size = new System.Drawing.Size(317, 175);
            this.lanuageGroupbox.TabIndex = 8;
            this.lanuageGroupbox.TabStop = false;
            this.lanuageGroupbox.Text = "Choose Your Language:";
            // 
            // englishRadioButton
            // 
            this.englishRadioButton.AutoSize = true;
            this.englishRadioButton.Location = new System.Drawing.Point(6, 42);
            this.englishRadioButton.Name = "englishRadioButton";
            this.englishRadioButton.Size = new System.Drawing.Size(114, 29);
            this.englishRadioButton.TabIndex = 0;
            this.englishRadioButton.TabStop = true;
            this.englishRadioButton.Text = "English";
            this.englishRadioButton.UseVisualStyleBackColor = true;
            // 
            // spanishRadiobutton
            // 
            this.spanishRadiobutton.AutoSize = true;
            this.spanishRadiobutton.Location = new System.Drawing.Point(6, 77);
            this.spanishRadiobutton.Name = "spanishRadiobutton";
            this.spanishRadiobutton.Size = new System.Drawing.Size(121, 29);
            this.spanishRadiobutton.TabIndex = 1;
            this.spanishRadiobutton.TabStop = true;
            this.spanishRadiobutton.Text = "Spanish";
            this.spanishRadiobutton.UseVisualStyleBackColor = true;
            // 
            // italianRadiobutton
            // 
            this.italianRadiobutton.AutoSize = true;
            this.italianRadiobutton.Location = new System.Drawing.Point(6, 112);
            this.italianRadiobutton.Name = "italianRadiobutton";
            this.italianRadiobutton.Size = new System.Drawing.Size(100, 29);
            this.italianRadiobutton.TabIndex = 2;
            this.italianRadiobutton.TabStop = true;
            this.italianRadiobutton.Text = "Italian";
            this.italianRadiobutton.UseVisualStyleBackColor = true;
            // 
            // Lab8
            // 
            this.AcceptButton = this.lookUpbutton;
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(443, 622);
            this.Controls.Add(this.lanuageGroupbox);
            this.Controls.Add(this.lookUpbutton);
            this.Controls.Add(this.monthOutputlabel);
            this.Controls.Add(this.monthNumbertextBox);
            this.Controls.Add(this.monthNumbertitleLabel);
            this.Name = "Lab8";
            this.Text = "Form1";
            this.lanuageGroupbox.ResumeLayout(false);
            this.lanuageGroupbox.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label monthNumbertitleLabel;
        private System.Windows.Forms.TextBox monthNumbertextBox;
        private System.Windows.Forms.Label monthOutputlabel;
        private System.Windows.Forms.Button lookUpbutton;
        private System.Windows.Forms.GroupBox lanuageGroupbox;
        private System.Windows.Forms.RadioButton italianRadiobutton;
        private System.Windows.Forms.RadioButton spanishRadiobutton;
        private System.Windows.Forms.RadioButton englishRadioButton;
    }
}

