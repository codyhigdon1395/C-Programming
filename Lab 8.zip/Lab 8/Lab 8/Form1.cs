﻿ /*B8978
 * Lab 8
 * April 2, 2017
 * CIS 199-02
 * This lab is designed to generate the name of a month in 3 different languages.
 */
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab_8
{
    public partial class Lab8 : Form
    {
        public Lab8()
        {
            InitializeComponent();
        }
        // PreConditions: The input can't be a letter imput or a number less than one and greater than 12
        // PostConditions: This will return a month in the output label
        public string GetEnglishMonth(int monthNumber) // This is the GetEnglishMonth Method & sets up month number
        {
            if (monthNumber > 0 && monthNumber < 13) // This if statement helps run the method
            {
                return englishNames[monthNumber - 1]; // This returns the value from the method

            }
            else // This else statment if the value isnt in the parameter
                return "Error!"; // This displays if not in parameter
        }
        string[] englishNames = { "January", "February", "March", "April", "May", "June", "July",
                                       "August", "September", "October", "November", "December"}; // This array for all English Months
        // PreConditions: The input can't be a letter imput or a number less than one and greater than 12
        // PostConditions: This will return a month in the output label
        public string GetSpanishMonth(int monthNumber) // This is GetSpanishMonth Method
        {
            if (monthNumber > 0 && monthNumber < 13) // This if statement runs the method
            {
                return spanishNames[monthNumber - 1]; // This returns the value from method
            }
            else // This else statment happens if outside parameter
                return "Error!"; // This displays if outside the parameter
        }
        string[] spanishNames = { "Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio", "Julio",
                                       "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre"}; // This displays the array of spanish months
        // PreConditions: The input can't be a letter imput or a number less than one and greater than 12
        // PostConditions: This will return a month in the output label
        public string GetItalianMonth(int monthNumber) // This GetItalianMonth Method
        {
            if (monthNumber > 0 && monthNumber < 13) // This if statement sets up the parameter
            {
                return italianNames[monthNumber - 1]; // This returns value from Italian Array
            }
            else
                return "Error!"; // This displays if value is outside the parameters
        }
        string[] italianNames = { "Gennaio", "Febbraio", "Marzo", "Aprile", "Maggio", "Giugno", "Luglio",
                                       "Agosto", "Settembre", "Ottobre", "Novembre", "Dicembre"}; // This is the array for for Ialian Months

        // PreConditions: The value has to be able to parse and it has to be an integer.
        // PostConditions: This will return a month in the output label
        private void lookUpbutton_Click(object sender, EventArgs e) // This is the click Event for finding the month name in particular language
        {
            int month; // This declared value to help return the method

            if (int.TryParse(monthNumbertextBox.Text, out month)) // This parses the value entered in the textbox
                {
                if (englishRadioButton.Checked) // This checks to see if English Radio Button is checked
                {
                    monthOutputlabel.Text = GetEnglishMonth(month);  // This displays output for English Months
                }
                else if (spanishRadiobutton.Checked) // This checks to see if Spanish Radio Button is checked
                {
                    monthOutputlabel.Text = GetSpanishMonth(month); // This displays the output for Spanish Months 
                }
                else // This is if Italian Radio Button is checked
                {
                    monthOutputlabel.Text = GetItalianMonth(month); // This displays Italian Month Outputs
                }
            }
        }
    }
}
