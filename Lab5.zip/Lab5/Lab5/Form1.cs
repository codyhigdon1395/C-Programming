﻿/* B8978
 * Lab 5
 * CIS 199-02
 * Runs Different Loops to preform certain tasks
 */ 
 using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab5
{
    public partial class Lab5 : Form
    {
        public Lab5()
        {
            InitializeComponent();
        }

        private void runLoopbutton_Click(object sender, EventArgs e)
        {
            int STARTINGNUMBER; // This is declared variable
            int ENDINGNUMBER; // This is declared variable

            if (int.TryParse(fromNumbertextBox.Text, out STARTINGNUMBER)) // This parses the value to an starting number
            {
                if (int.TryParse(toNumbertextBox.Text, out ENDINGNUMBER)) // This parses the value to an ending number
                {
                    if (whileLoopbutton.Checked) // This checks to see if the while loop is checked
                    {
                        while (STARTINGNUMBER <= ENDINGNUMBER) // This is the while loop
                        {
                            numberOutputlistBox.Items.Add(STARTINGNUMBER); // This adds to output list 
                            STARTINGNUMBER++; // This adds to the starting number line
                        }
                    }
                    else if (forLoopradioButton.Checked) // This determines if the for loop is checked
                    {
                        for (int count = STARTINGNUMBER; count <= ENDINGNUMBER; count++) // This the for loop
                        {
                            numberOutputlistBox.Items.Add(STARTINGNUMBER); // This adds to output lsit.
                            STARTINGNUMBER++; // This adds a number to starting number
                        }
                    }
                    else // This is the else statement for equation
                    {
                        do // This the do for the do while loop
                        {
                            numberOutputlistBox.Items.Add(STARTINGNUMBER); // This adds number to output list
                            STARTINGNUMBER++; // This adds to starting number
                        }
                        while (STARTINGNUMBER <= ENDINGNUMBER);// This is the while intiator
                    } 
                }
                else
                    MessageBox.Show("Invalid Ending Point"); // This shows the number to be invalid if wasnt able to parse.

            }
                else 
                    MessageBox.Show("Invalid Starting Number"); // This shows the number to be invalid if wasnt able to parse.
        }
        private void clearListbutton_Click(object sender, EventArgs e) // This is the click event for clear button
        {
            numberOutputlistBox.Items.Clear(); // This clears the number output of the list
        }
    } }
