﻿namespace Lab5
{
    partial class Lab5
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.fromTitlelabel = new System.Windows.Forms.Label();
            this.fromNumbertextBox = new System.Windows.Forms.TextBox();
            this.toTitlelabel = new System.Windows.Forms.Label();
            this.toNumbertextBox = new System.Windows.Forms.TextBox();
            this.buttonsGroupbox = new System.Windows.Forms.GroupBox();
            this.doWhileradioButton = new System.Windows.Forms.RadioButton();
            this.forLoopradioButton = new System.Windows.Forms.RadioButton();
            this.whileLoopbutton = new System.Windows.Forms.RadioButton();
            this.numberOutputlistBox = new System.Windows.Forms.ListBox();
            this.runLoopbutton = new System.Windows.Forms.Button();
            this.clearListbutton = new System.Windows.Forms.Button();
            this.buttonsGroupbox.SuspendLayout();
            this.SuspendLayout();
            // 
            // fromTitlelabel
            // 
            this.fromTitlelabel.AutoSize = true;
            this.fromTitlelabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.fromTitlelabel.Location = new System.Drawing.Point(26, 48);
            this.fromTitlelabel.Name = "fromTitlelabel";
            this.fromTitlelabel.Size = new System.Drawing.Size(69, 27);
            this.fromTitlelabel.TabIndex = 0;
            this.fromTitlelabel.Text = "From:";
            // 
            // fromNumbertextBox
            // 
            this.fromNumbertextBox.Location = new System.Drawing.Point(26, 100);
            this.fromNumbertextBox.Name = "fromNumbertextBox";
            this.fromNumbertextBox.Size = new System.Drawing.Size(165, 31);
            this.fromNumbertextBox.TabIndex = 1;
            // 
            // toTitlelabel
            // 
            this.toTitlelabel.AutoSize = true;
            this.toTitlelabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.toTitlelabel.Location = new System.Drawing.Point(26, 163);
            this.toTitlelabel.Name = "toTitlelabel";
            this.toTitlelabel.Size = new System.Drawing.Size(45, 27);
            this.toTitlelabel.TabIndex = 2;
            this.toTitlelabel.Text = "To:";
            // 
            // toNumbertextBox
            // 
            this.toNumbertextBox.Location = new System.Drawing.Point(26, 212);
            this.toNumbertextBox.Name = "toNumbertextBox";
            this.toNumbertextBox.Size = new System.Drawing.Size(164, 31);
            this.toNumbertextBox.TabIndex = 3;
            // 
            // buttonsGroupbox
            // 
            this.buttonsGroupbox.Controls.Add(this.doWhileradioButton);
            this.buttonsGroupbox.Controls.Add(this.forLoopradioButton);
            this.buttonsGroupbox.Controls.Add(this.whileLoopbutton);
            this.buttonsGroupbox.Location = new System.Drawing.Point(22, 288);
            this.buttonsGroupbox.Name = "buttonsGroupbox";
            this.buttonsGroupbox.Size = new System.Drawing.Size(184, 190);
            this.buttonsGroupbox.TabIndex = 4;
            this.buttonsGroupbox.TabStop = false;
            this.buttonsGroupbox.Text = "Loops:";
            // 
            // doWhileradioButton
            // 
            this.doWhileradioButton.AutoSize = true;
            this.doWhileradioButton.Location = new System.Drawing.Point(0, 111);
            this.doWhileradioButton.Name = "doWhileradioButton";
            this.doWhileradioButton.Size = new System.Drawing.Size(131, 29);
            this.doWhileradioButton.TabIndex = 2;
            this.doWhileradioButton.TabStop = true;
            this.doWhileradioButton.Text = "Do-While";
            this.doWhileradioButton.UseVisualStyleBackColor = true;
            // 
            // forLoopradioButton
            // 
            this.forLoopradioButton.AutoSize = true;
            this.forLoopradioButton.Location = new System.Drawing.Point(0, 76);
            this.forLoopradioButton.Name = "forLoopradioButton";
            this.forLoopradioButton.Size = new System.Drawing.Size(75, 29);
            this.forLoopradioButton.TabIndex = 1;
            this.forLoopradioButton.TabStop = true;
            this.forLoopradioButton.Text = "For";
            this.forLoopradioButton.UseVisualStyleBackColor = true;
            // 
            // whileLoopbutton
            // 
            this.whileLoopbutton.AutoSize = true;
            this.whileLoopbutton.Location = new System.Drawing.Point(0, 41);
            this.whileLoopbutton.Name = "whileLoopbutton";
            this.whileLoopbutton.Size = new System.Drawing.Size(97, 29);
            this.whileLoopbutton.TabIndex = 0;
            this.whileLoopbutton.TabStop = true;
            this.whileLoopbutton.Text = "While";
            this.whileLoopbutton.UseVisualStyleBackColor = true;
            // 
            // numberOutputlistBox
            // 
            this.numberOutputlistBox.FormattingEnabled = true;
            this.numberOutputlistBox.ItemHeight = 25;
            this.numberOutputlistBox.Location = new System.Drawing.Point(362, 72);
            this.numberOutputlistBox.Name = "numberOutputlistBox";
            this.numberOutputlistBox.Size = new System.Drawing.Size(299, 554);
            this.numberOutputlistBox.TabIndex = 5;
            // 
            // runLoopbutton
            // 
            this.runLoopbutton.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.runLoopbutton.Location = new System.Drawing.Point(30, 520);
            this.runLoopbutton.Name = "runLoopbutton";
            this.runLoopbutton.Size = new System.Drawing.Size(194, 50);
            this.runLoopbutton.TabIndex = 6;
            this.runLoopbutton.Text = "Run Loop";
            this.runLoopbutton.UseVisualStyleBackColor = true;
            this.runLoopbutton.Click += new System.EventHandler(this.runLoopbutton_Click);
            // 
            // clearListbutton
            // 
            this.clearListbutton.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.clearListbutton.Location = new System.Drawing.Point(39, 614);
            this.clearListbutton.Name = "clearListbutton";
            this.clearListbutton.Size = new System.Drawing.Size(185, 47);
            this.clearListbutton.TabIndex = 7;
            this.clearListbutton.Text = "Clear List";
            this.clearListbutton.UseVisualStyleBackColor = true;
            this.clearListbutton.Click += new System.EventHandler(this.clearListbutton_Click);
            // 
            // Lab5
            // 
            this.AcceptButton = this.runLoopbutton;
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.clearListbutton;
            this.ClientSize = new System.Drawing.Size(707, 867);
            this.Controls.Add(this.clearListbutton);
            this.Controls.Add(this.runLoopbutton);
            this.Controls.Add(this.numberOutputlistBox);
            this.Controls.Add(this.buttonsGroupbox);
            this.Controls.Add(this.toNumbertextBox);
            this.Controls.Add(this.toTitlelabel);
            this.Controls.Add(this.fromNumbertextBox);
            this.Controls.Add(this.fromTitlelabel);
            this.Name = "Lab5";
            this.Text = "Lab5";
            this.buttonsGroupbox.ResumeLayout(false);
            this.buttonsGroupbox.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label fromTitlelabel;
        private System.Windows.Forms.TextBox fromNumbertextBox;
        private System.Windows.Forms.Label toTitlelabel;
        private System.Windows.Forms.TextBox toNumbertextBox;
        private System.Windows.Forms.GroupBox buttonsGroupbox;
        private System.Windows.Forms.RadioButton doWhileradioButton;
        private System.Windows.Forms.RadioButton forLoopradioButton;
        private System.Windows.Forms.RadioButton whileLoopbutton;
        private System.Windows.Forms.ListBox numberOutputlistBox;
        private System.Windows.Forms.Button runLoopbutton;
        private System.Windows.Forms.Button clearListbutton;
    }
}

