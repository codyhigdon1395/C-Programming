﻿/* 
B8978
Lab #1
January 29th 2017
CIS 199-02
Lab 1 is a program that displays my interests when Prompted.
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab1
{
    public partial class Lab1 : Form
    {
        public Lab1()
        {
            InitializeComponent(); 
        }

        private void hobbiesButton_Click(object sender, EventArgs e) // This is a click event for hobbies button.
        {
            MessageBox.Show ("I enjoy spending time with family and friends. I also love watching & playing sports."); // This message box displays my favorite hobbies.
        }

        private void bookButton_Click(object sender, EventArgs e) // This is a click event for book button.
        {
            MessageBox.Show("The Da Vinci Code By Dan Brown"); // This message box displays my favorite book.
        }

        private void movieButton_Click(object sender, EventArgs e) // This is a click event for my favorite movie button.
        {
            MessageBox.Show("Remember The Titans."); // This message box displays my favorite movie.
        }
    }
}
