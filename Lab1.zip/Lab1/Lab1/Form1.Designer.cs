﻿namespace Lab1
{
    partial class Lab1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Lab1));
            this.chuckPicturebox = new System.Windows.Forms.PictureBox();
            this.gradingIDlabel = new System.Windows.Forms.Label();
            this.hobbiesButton = new System.Windows.Forms.Button();
            this.bookButton = new System.Windows.Forms.Button();
            this.movieButton = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.chuckPicturebox)).BeginInit();
            this.SuspendLayout();
            // 
            // chuckPicturebox
            // 
            this.chuckPicturebox.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)));
            this.chuckPicturebox.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.chuckPicturebox.Image = ((System.Drawing.Image)(resources.GetObject("chuckPicturebox.Image")));
            this.chuckPicturebox.Location = new System.Drawing.Point(140, 48);
            this.chuckPicturebox.Name = "chuckPicturebox";
            this.chuckPicturebox.Size = new System.Drawing.Size(519, 471);
            this.chuckPicturebox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.chuckPicturebox.TabIndex = 0;
            this.chuckPicturebox.TabStop = false;
            this.chuckPicturebox.Tag = "";
            // 
            // gradingIDlabel
            // 
            this.gradingIDlabel.AutoSize = true;
            this.gradingIDlabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gradingIDlabel.Location = new System.Drawing.Point(344, 555);
            this.gradingIDlabel.Name = "gradingIDlabel";
            this.gradingIDlabel.Size = new System.Drawing.Size(110, 37);
            this.gradingIDlabel.TabIndex = 1;
            this.gradingIDlabel.Text = "B8978";
            this.gradingIDlabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // hobbiesButton
            // 
            this.hobbiesButton.Location = new System.Drawing.Point(59, 614);
            this.hobbiesButton.Name = "hobbiesButton";
            this.hobbiesButton.Size = new System.Drawing.Size(202, 50);
            this.hobbiesButton.TabIndex = 2;
            this.hobbiesButton.Text = "Hobbies";
            this.hobbiesButton.UseVisualStyleBackColor = true;
            this.hobbiesButton.Click += new System.EventHandler(this.hobbiesButton_Click);
            // 
            // bookButton
            // 
            this.bookButton.Location = new System.Drawing.Point(310, 614);
            this.bookButton.Name = "bookButton";
            this.bookButton.Size = new System.Drawing.Size(190, 50);
            this.bookButton.TabIndex = 3;
            this.bookButton.Text = "Book";
            this.bookButton.UseVisualStyleBackColor = true;
            this.bookButton.Click += new System.EventHandler(this.bookButton_Click);
            // 
            // movieButton
            // 
            this.movieButton.Location = new System.Drawing.Point(579, 614);
            this.movieButton.Name = "movieButton";
            this.movieButton.Size = new System.Drawing.Size(186, 50);
            this.movieButton.TabIndex = 4;
            this.movieButton.Text = "Movie";
            this.movieButton.UseVisualStyleBackColor = true;
            this.movieButton.Click += new System.EventHandler(this.movieButton_Click);
            // 
            // Lab1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(799, 810);
            this.Controls.Add(this.movieButton);
            this.Controls.Add(this.bookButton);
            this.Controls.Add(this.hobbiesButton);
            this.Controls.Add(this.gradingIDlabel);
            this.Controls.Add(this.chuckPicturebox);
            this.Name = "Lab1";
            this.Text = "Lab 1";
            ((System.ComponentModel.ISupportInitialize)(this.chuckPicturebox)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox chuckPicturebox;
        private System.Windows.Forms.Label gradingIDlabel;
        private System.Windows.Forms.Button hobbiesButton;
        private System.Windows.Forms.Button bookButton;
        private System.Windows.Forms.Button movieButton;
    }
}

